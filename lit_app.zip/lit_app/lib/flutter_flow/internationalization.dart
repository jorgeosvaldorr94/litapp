import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['es', 'en'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? esText = '',
    String? enText = '',
  }) =>
      [esText, enText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // I50InicioPerfil
  {
    'w668u0ep': {
      'es': 'INFLUENCER',
      'en': 'INFLUENCER',
    },
    '3floxn8e': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    '5lwiyoer': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I00INICIO
  {
    '387f0t2a': {
      'es': 'INICIAR SESION',
      'en': 'LOG IN',
    },
    'hgdajudm': {
      'es': 'REGISTRARSE',
      'en': 'REGISTER',
    },
    'dexeokal': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I07InicioSecionComun
  {
    'qk9kr3vc': {
      'es': 'INFLUENCERS',
      'en': 'INFLUENCERS',
    },
    'aq6mnpob': {
      'es': 'Iniciar Sesión',
      'en': 'login',
    },
    'wjn72zq7': {
      'es': 'Email',
      'en': 'Email',
    },
    '233sok0q': {
      'es': 'Olvidé mi mail',
      'en': 'Forgot Password',
    },
    '28oyqje9': {
      'es': 'Contraseña',
      'en': 'Password',
    },
    'ucfw6ed1': {
      'es': 'Olvide mi contraseña',
      'en': 'Forgot Password',
    },
    'dso4mwgj': {
      'es': 'Use las redes sociales para iniciar sesion',
      'en': 'Login with Social Networks',
    },
    '1gwusawk': {
      'es': 'INICIAR SESION',
      'en': 'LOGIN',
    },
    'wcx3kh6r': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I08ReseteoContrasena
  {
    'qany14gn': {
      'es': 'INFLUENCERS',
      'en': 'INFLUENCERS',
    },
    '3nbg97cr': {
      'es': 'Cambiar Contraseña',
      'en': 'Change Password',
    },
    '4zv7bgjg': {
      'es': 'E-mail',
      'en': 'E-mail',
    },
    'i5eq2q5h': {
      'es': 'ENVIAR CÓDIGO',
      'en': 'SEND CODE',
    },
    '228662sx': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I11verificaciondecodigo
  {
    'frzgb4aa': {
      'es': 'INFLUENCERS',
      'en': 'INFLUENCERS',
    },
    'uefxx5l1': {
      'es': 'Cambiar Contraseña',
      'en': 'Cambiar Contraseña',
    },
    '7a21mb0m': {
      'es': 'REENVIAR CÓDIGO',
      'en': 'REENVIAR CÓDIGO',
    },
    'mi7uy3m7': {
      'es': '¿No te llegó el mail? Contactarme \ncon ',
      'en': '¿No te llegó el mail? Contactarme \ncon ',
    },
    't9g1drhx': {
      'es': 'soporte técnico',
      'en': 'soporte técnico',
    },
    'zfglz8q3': {
      'es': 'ENVIAR CÓDIGO',
      'en': 'ENVIAR CÓDIGO',
    },
    'kpzlikr4': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I12NuevaContrasena
  {
    'h3zzqumw': {
      'es': 'INFLUENCERS',
      'en': 'INFLUENCERS',
    },
    'r8b94hwd': {
      'es': 'Nueva Contraseña',
      'en': 'Nueva Contraseña',
    },
    'z6kwrj8c': {
      'es': 'Contraseña',
      'en': 'Contraseña',
    },
    'fq83067z': {
      'es': 'Nueva Contraseña',
      'en': 'Nueva Contraseña',
    },
    '2jrf6sqv': {
      'es': 'CONFIRMAR',
      'en': 'CONFIRMAR',
    },
    'btks0r4k': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I01RegistrarPaso1
  {
    '7xwzd3ul': {
      'es': '1',
      'en': '1',
    },
    'mqz5xehl': {
      'es': '2',
      'en': '2',
    },
    'up8ct5i7': {
      'es': '3',
      'en': '3',
    },
    'vlffg9jx': {
      'es': 'Registrar',
      'en': 'Log in',
    },
    '2ri837qc': {
      'es': 'E-mail',
      'en': 'Email',
    },
    '4xo0u3yc': {
      'es': 'Contraseña',
      'en': 'Password',
    },
    '912gsmqc': {
      'es': 'Confirmar Contraseña',
      'en': 'Confirm Password',
    },
    'pvt3efh2': {
      'es': 'Use las redes sociales para registrarte',
      'en': 'Use social networks to register',
    },
    'iq6vnd6p': {
      'es': '¿Ya tenés cuenta?',
      'en': 'Do you already have an account?',
    },
    '8mft0x2d': {
      'es': 'Ingresá acá',
      'en': 'Enter here',
    },
    'buyqwset': {
      'es': 'Acepto los términos y condiciones',
      'en': 'I accept the terms and conditions',
    },
    'as0gfc3t': {
      'es':
          'Si se han realizado cambios en la estructura de la colección en la base de datos, como la eliminación o modificación de campos, puede afectar cómo se muestra en webligth. Asegúrate de que la estructura de la colección sea coherente en ambos lugares y que no haya cambios que impidan que webligth la muestre correctamente.',
      'en':
          'Si se han realizado cambios en la estructura de la colección en la base de datos, como la eliminación o modificación de campos, puede afectar cómo se muestra en webligth. Asegúrate de que la estructura de la colección sea coherente en ambos lugares y que no haya cambios que impidan que webligth la muestre correctamente.',
    },
    'bqpvxfph': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    'gky8muki': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I01RegistracionError
  {
    'aa04pzjo': {
      'es': '1',
      'en': '',
    },
    '9amjl0ol': {
      'es': '2',
      'en': '',
    },
    '18h097kj': {
      'es': '3',
      'en': '',
    },
    'vsgtflkq': {
      'es': 'INFLUENCERS',
      'en': '',
    },
    'o8dde5cv': {
      'es': 'Registrar',
      'en': '',
    },
    'mqb6hqws': {
      'es': 'E-mail',
      'en': '',
    },
    '0z9dn8j0': {
      'es': 'Confirmar E-mail',
      'en': '',
    },
    '19v376ks': {
      'es': 'Contraseña',
      'en': '',
    },
    'n5habt6o': {
      'es': 'Confirmar Contraseña',
      'en': '',
    },
    '1xirq9hd': {
      'es': 'Acepto los términos y condiciones',
      'en': '',
    },
    'aw95f65f': {
      'es': '¿Ya tenés cuenta?',
      'en': '',
    },
    '1gjtlsty': {
      'es': 'Ingresá acá',
      'en': '',
    },
    'ucdiuwdz': {
      'es': 'CONTINUAR',
      'en': '',
    },
    'cyzwki34': {
      'es': 'Home',
      'en': '',
    },
  },
  // I56RegistrarPaso2
  {
    '8rah3s6g': {
      'es': '1',
      'en': '1',
    },
    '3n4ow2vh': {
      'es': '2',
      'en': '2',
    },
    'c74gdxne': {
      'es': '3',
      'en': '3',
    },
    '4v2vstcp': {
      'es': 'INFLUENCERS',
      'en': 'INFLUENCERS',
    },
    '6ly8g8cb': {
      'es': 'Registrar',
      'en': 'Register',
    },
    'cv8kkjdf': {
      'es': 'Nombre',
      'en': 'Name',
    },
    'h3hljv0n': {
      'es': 'Apellido',
      'en': 'Last Name',
    },
    'xdsm5lnx': {
      'es': 'Cdo. Área',
      'en': 'Cdo. Área',
    },
    'e8961qws': {
      'es': 'Teléfono (opcional)',
      'en': 'Phone(optional)',
    },
    '4sqa8teb': {
      'es': 'Ubicacion',
      'en': 'Location',
    },
    'hfdku8xz': {
      'es': 'Profesion',
      'en': 'Profession',
    },
    'adighjht': {
      'es': 'Representante',
      'en': 'Representative',
    },
    'tiaej61e': {
      'es': 'Nombre del representante',
      'en': 'Representative Name',
    },
    'xseeh191': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    '480wstff': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I04RegistrarPaso3
  {
    'yc79699d': {
      'es': '1',
      'en': '1',
    },
    '4gyxkq1h': {
      'es': '2',
      'en': '2',
    },
    'vl4vkq5n': {
      'es': '3',
      'en': '3',
    },
    'jdmhlupr': {
      'es': 'INFLUENCERS',
      'en': 'INFLUENCERS',
    },
    'x50fbynn': {
      'es': 'Link a tus redes',
      'en': 'Network Link',
    },
    'qyrxvddu': {
      'es': 'Al menos 1 obligatorio',
      'en': 'at least 1 required',
    },
    'rlx7q2t0': {
      'es': 'Instagram',
      'en': 'Instagram',
    },
    'xuh85w3t': {
      'es': 'Tik Tok',
      'en': 'Tik Tok',
    },
    'dpm3r9bd': {
      'es': 'Youtube',
      'en': 'Youtube',
    },
    'vq0h09ib': {
      'es': 'Twitch',
      'en': 'Twitch',
    },
    'hdhstc83': {
      'es': 'Portfolio',
      'en': 'Portfolio',
    },
    'nvn6gagv': {
      'es': 'Link de tu portfolio',
      'en': 'Portfolio Link',
    },
    'hwza0lfx': {
      'es': 'Fotos de tu portfolio (opcionales)',
      'en': 'Portfolio Galery(optional)',
    },
    'ja6cophw': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    '28eeqmbb': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I0X1HOMEInfluencersinofertas
  {
    'wbjtqnk7': {
      'es': 'Influencer',
      'en': 'Influencer',
    },
    'rykpmmst': {
      'es': '¡Bienvenid@ a Lit!',
      'en': 'Welcome to Lit!',
    },
    'acrwulx4': {
      'es': 'Hola  ',
      'en': 'Hello',
    },
    'sdrvseik': {
      'es':
          'Ya sos parte de nuestra\ncomunidad. Aceptá tu primera oferta y empezá\na disfrutar miles de experiencias',
      'en':
          'You are already part of our\ncommunity. Accept your first offer and get started\nto enjoy thousands of experiences',
    },
    'fvwz2nep': {
      'es': 'Todavía no tenés ofertas!',
      'en': 'You still have no offers!',
    },
    'bxz4vove': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I20listadodeofertas
  {
    '2go60xkj': {
      'es': 'Ofertas',
      'en': 'Offers',
    },
    'c2cdvwew': {
      'es': 'Comida',
      'en': 'Food',
    },
    'cvawfwdg': {
      'es': 'Fitness',
      'en': 'Fitness',
    },
    'b70am1wt': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I21detalledeoferta
  {
    '5tsctyxi': {
      'es': '2km',
      'en': '2km',
    },
    'i1txylr2': {
      'es': 'Código - AD1234 ',
      'en': 'Código - AD1234 ',
    },
    '8dcqwbka': {
      'es': 'Dejanos tu reseña en Google!\n',
      'en': 'Leave us your review on Google!',
    },
    '485a9hew': {
      'es': 'ACEPTAR',
      'en': 'ACCEPT',
    },
    '236yjdpb': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I24missolicitudes
  {
    'hkud7ua5': {
      'es': 'Mis solicitudes',
      'en': 'My requests',
    },
    'yp8qpp6k': {
      'es': 'En proceso',
      'en': 'In progress',
    },
    'vtwxsefq': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I25Detalledesolicitud
  {
    'cg0497t5': {
      'es': 'Drinks + entrada',
      'en': 'Drinks + entrada',
    },
    'hwbv57ly': {
      'es': 'Pasá entre las 18:00 - 19:30pm',
      'en': 'Pasá entre las 18:00 - 19:30pm',
    },
    'j0pu6nkh': {
      'es': '2km',
      'en': '2km',
    },
    'nh5vrgow': {
      'es': 'NEGRONI',
      'en': 'NEGRONI',
    },
    '2nzzldb6': {
      'es': 'Av. Santa Fe 19888',
      'en': 'Av. Santa Fe 19888',
    },
    'fjb9imrn': {
      'es': 'Código - AD1234 ',
      'en': 'Código - AD1234 ',
    },
    's0uld9cm': {
      'es':
          'Disfrutá una porción de pan o ensalada de \ncortesía + una Provoleta Negroni o unos\nLangostinos de Roca o unas Papas Bravas + 2 \ntragos a elección.',
      'en':
          'Disfrutá una porción de pan o ensalada de \ncortesía + una Provoleta Negroni o unos\nLangostinos de Roca o unas Papas Bravas + 2 \ntragos a elección.',
    },
    'bjdgeooc': {
      'es': 'Dejanos tu reseña en Google!\n',
      'en': '',
    },
    'dngvnz67': {
      'es': 'Home',
      'en': '',
    },
  },
  // I28Atencionalcliente
  {
    'jnh6bo3s': {
      'es': 'Atención al Cliente',
      'en': 'Atención al Cliente',
    },
    'nn73bwaq': {
      'es': 'Martes, 15',
      'en': 'Martes, 15',
    },
    'iq76rwiw': {
      'es':
          'Ey! ¿Cómo podemos ayudarte?\nSi estás teniendo problemas\ncon la app mandá:',
      'en':
          'Ey! ¿Cómo podemos ayudarte?\nSi estás teniendo problemas\ncon la app mandá:',
    },
    'wyiz1bl1': {
      'es': '. ',
      'en': '.',
    },
    '1qs1cicz': {
      'es': '1. Tengo un problema\ncon la oferta.',
      'en': '1. Tengo un problema\ncon la oferta.',
    },
    'x7ko1hxh': {
      'es': '8.30pm',
      'en': '8.30pm',
    },
    'r8izvh1o': {
      'es':
          'Hola! ¿Qué tal? Sí,\ngracias! 1. tengo un\nproblema con la\noferta.',
      'en':
          'Hola! ¿Qué tal? Sí,\ngracias! 1. tengo un\nproblema con la\noferta.',
    },
    'dm1jly9t': {
      'es': '8.33pm',
      'en': '8.33pm',
    },
    '2gyc62sg': {
      'es': 'Escribir...',
      'en': 'Escribir...',
    },
    'uub2pr8w': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // i194vacarchat
  {
    'sq05mjol': {
      'es': 'Atención al Cliente',
      'en': 'Atención al Cliente',
    },
    'dlwdojew': {
      'es': 'Martes, 15',
      'en': 'Martes, 15',
    },
    'ih2iqd6c': {
      'es': 'Todavía no tenés mensajes!',
      'en': 'Todavía no tenés mensajes!',
    },
    'kgiugcuc': {
      'es': 'Escribir...',
      'en': 'Escribir...',
    },
    'j24tzi0l': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I29Calendario
  {
    '1iba03c9': {
      'es': 'Calendario',
      'en': 'Calendar',
    },
    'lnrjyvtm': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I30acciones
  {
    'oavy4h8g': {
      'es': 'Calendario',
      'en': 'Calendar',
    },
    '3jtnse9k': {
      'es': 'INFLUENCERS',
      'en': 'INFLUENCERS',
    },
    'o8uh5tnt': {
      'es': '2 de septiembre',
      'en': '2 de septiembre',
    },
    'h2sa26dw': {
      'es': '2021',
      'en': '2021',
    },
    'ocwvpj31': {
      'es': '10:00-13:00',
      'en': '10:00-13:00',
    },
    'jb5w6qqc': {
      'es': 'Acción instagram -  Fiesta',
      'en': 'Acción instagram -  Fiesta',
    },
    'us3wcc01': {
      'es': '3 historias , ropa fiesta',
      'en': '3 historias , ropa fiesta',
    },
    'g9yizmu9': {
      'es': '14:00-15:00',
      'en': '14:00-15:00',
    },
    '71wxu0n9': {
      'es': 'Tik Tok - GRWM',
      'en': 'Tik Tok - GRWM',
    },
    'dhz4cnzv': {
      'es': 'Define the problem or question that....',
      'en': 'Define the problem or question that....',
    },
    'fxqdr8sn': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I40Notificaciones
  {
    '63wj9nlb': {
      'es': 'Notificaciones',
      'en': 'Notificaciones',
    },
    'p18c2eg8': {
      'es': 'Borrar Historial',
      'en': 'Borrar Historial',
    },
    '8wqwsuoq': {
      'es': '¡Este mes tuviste 30 contrataciones!',
      'en': '¡Este mes tuviste 30 contrataciones!',
    },
    'k9a5mx7g': {
      'es': 'Hoy 12:00',
      'en': 'Hoy 12:00',
    },
    'lpljnq8t': {
      'es': '¡Ahora sos Mega Influencer!',
      'en': '¡Ahora sos Mega Influencer!',
    },
    'espiv19h': {
      'es': 'Hoy 12:00',
      'en': 'Hoy 12:00',
    },
    '7hsorica': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I192sinnotificaciones
  {
    'owsqfd4j': {
      'es': 'Atención al Cliente',
      'en': 'Atención al Cliente',
    },
    'n13vl4wd': {
      'es': 'No tenés notificaciones!',
      'en': 'No tenés notificaciones!',
    },
    'mduy6g4f': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I33PerfilComun
  {
    'ee6chbyj': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    'xqbdnti2': {
      'es': 'Mi cuenta',
      'en': 'My Account',
    },
    'bq7otfc8': {
      'es': 'Usuario, contraseña...',
      'en': 'User, password...',
    },
    'jl5fwx31': {
      'es': 'Mis Ofertas',
      'en': 'My Offers',
    },
    'uvubj8pr': {
      'es': 'Ir a mis ofertas...',
      'en': 'Go to my offers...',
    },
    'f8ok4wmg': {
      'es': 'Crear Oferta',
      'en': 'Add Offer',
    },
    'vnv4mdb1': {
      'es': 'Crear Nueva Oferta...',
      'en': 'Add a new offer...',
    },
    'yl7m6equ': {
      'es': 'Atencion al cliente',
      'en': 'Customer Support',
    },
    'j0pvckff': {
      'es': 'Responde tus preguntas...',
      'en': 'Answer your questions...',
    },
    'pd4juk8v': {
      'es': 'Salir del Perfil',
      'en': 'Log out',
    },
    'rcqu6gry': {
      'es': 'Salir del perfil...',
      'en': 'Log out',
    },
    'kc67mpfx': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I37ajustesdeperfilNOesElqVA
  {
    '72x7xb3k': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    'o5js6wsu': {
      'es': 'Mi cuenta',
      'en': 'My Profile',
    },
    'y7w8zqmk': {
      'es': 'Editar perfil...',
      'en': 'Edit profile',
    },
    '4k8f3knh': {
      'es': 'Soporte Técnico',
      'en': 'Technical support',
    },
    '6ojnhlwn': {
      'es': 'Responde tus preguntas...',
      'en': 'Answer your questions...',
    },
    'ud9evqcj': {
      'es': 'Método de pago',
      'en': 'Payment method',
    },
    'utynvfdi': {
      'es': 'Mejor manera de recibir los....',
      'en': 'Best way to receive...',
    },
    'dgo2m3qb': {
      'es': 'CERRAR SESIÓN',
      'en': 'LOG OUT',
    },
    'w4xhs6ag': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I34EditarPerfilInfluencer
  {
    'mfugnw33': {
      'es': 'Editar Cuenta',
      'en': 'My Account',
    },
    '2acipo0p': {
      'es': 'Información personal',
      'en': 'Personal Information',
    },
    '7bmqmmvk': {
      'es': 'Claudia Fernandez',
      'en': 'Claudia Fernandez',
    },
    'wm7mdsbc': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    'jh9g08wh': {
      'es': '10/09/2023',
      'en': '10/09/2023',
    },
    'rvr40pqu': {
      'es': '@Clau.fer',
      'en': '@Clau.fer',
    },
    '0nml61sm': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    'wcrpkcuz': {
      'es': 'Ubicación',
      'en': 'Location',
    },
    '7dnalxla': {
      'es': 'Ubicacion',
      'en': '',
    },
    'ogpxahha': {
      'es': 'Dirección',
      'en': 'Address',
    },
    'br6odjqp': {
      'es': 'Actualizar Ubicacion',
      'en': 'Update Location',
    },
    'hziiu1zh': {
      'es': 'Ir a mí Ubicación',
      'en': 'Go to my Location',
    },
    'hfykimr9': {
      'es': 'GUARDAR CAMBIOS',
      'en': 'SAVE CHANGES',
    },
    '9gasrcsn': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // IAtencionalcliente
  {
    '9tt2bnzj': {
      'es': 'Atención al Cliente',
      'en': 'Atención al Cliente',
    },
    'nsc7nr4d': {
      'es':
          'Ey! ¿Cómo podemos ayudarte?\nSi estás teniendo problemas\ncon la app mandá:\n\n             1. Servicios Técnicos\n             2.Problemas con la \n                Oferta',
      'en':
          'Hola! ¿Qué tal? Sí,\ngracias! 1. tengo un\nproblema con la\noferta.',
    },
    'am398tnn': {
      'es': '8.33pm',
      'en': '8.33pm',
    },
    'u6bs2dfl': {
      'es': '',
      'en': 'Label here...',
    },
    'nz93bnds': {
      'es': 'Escribir Aqui...',
      'en': 'Write here...',
    },
    'l778mypg': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I38Metododepago
  {
    '2zzm77l8': {
      'es': 'Método de pago',
      'en': 'Método de pago',
    },
    'rv2qoimg': {
      'es': 'Sincronizar',
      'en': 'Sincronizar',
    },
    '2vnwefh3': {
      'es': 'Sincronizar',
      'en': 'Sincronizar',
    },
    'ikb53bke': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I190splash
  {
    '90nxe6uz': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I50selector
  {
    'duv4r07f': {
      'es': 'INFLUENCER',
      'en': 'INFLUENCER',
    },
    'x0nf9gfg': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    '6rzwc5rq': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I7Presentacion
  {
    'wlzmruvm': {
      'es': 'Influencer',
      'en': 'Influencer',
    },
    'mh1eqgje': {
      'es': 'Creá ofertas',
      'en': 'Creá ofertas',
    },
    'd1x7dy1p': {
      'es': 'Hacé que tu negocio despegue con nuestros influencers\n',
      'en': 'Hacé que tu negocio despegue con nuestros influencers\n',
    },
    'vbs7b0cw': {
      'es': 'Encontrá al influencer indicado ',
      'en': 'Encontrá al influencer indicado ',
    },
    'syvrkqm7': {
      'es': 'Conectá directamente con todo el talento de nuestra comunidad ',
      'en': 'Conectá directamente con todo el talento de nuestra comunidad ',
    },
    'pdrfijfa': {
      'es': 'Potenciá tu negocio',
      'en': 'Potenciá tu negocio',
    },
    'waru4gg0': {
      'es': 'Video Tutorial',
      'en': 'Video Tutorial',
    },
    '4otlrqq9': {
      'es': 'EMPEZAR',
      'en': 'EMPEZAR',
    },
    'vke7uhou': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I0Seleccion
  {
    'ey1ep132': {
      'es': 'INICIAR SESION',
      'en': 'LOG IN',
    },
    '8axrvns8': {
      'es': 'REGISTRARSE',
      'en': 'REGISTER',
    },
    'i1e4irdz': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I10RegistrarComercio1
  {
    'wqaasxlg': {
      'es': '1',
      'en': '1',
    },
    'rf1zsq0b': {
      'es': '2',
      'en': '2',
    },
    '3j8xmrtt': {
      'es': '3',
      'en': '3',
    },
    'shcwuo4c': {
      'es': 'Registrar',
      'en': 'Register',
    },
    'c3yzosbg': {
      'es': 'E-mail',
      'en': 'Email',
    },
    'yyjbsl8o': {
      'es': 'Contraseña',
      'en': 'Password',
    },
    'aiv0fzcb': {
      'es': 'Confirmar Contraseña',
      'en': 'Confirm Password',
    },
    'jjcsd2bt': {
      'es': '¿Ya tenés cuenta?',
      'en': 'Have Account?',
    },
    'yr8no3ik': {
      'es': 'Ingresá acá',
      'en': 'Enter here',
    },
    'hy8m2bid': {
      'es': 'Use las redes sociales para registrarte',
      'en': 'Use social networks to register',
    },
    'lbi3xkj2': {
      'es': 'Acepto los términos y condiciones',
      'en': 'Accept the terms and conditions',
    },
    'sbt90m77': {
      'es':
          'Si se han realizado cambios en la estructura de la colección en la base de datos, como la eliminación o modificación de campos, puede afectar cómo se muestra en webligth. Asegúrate de que la estructura de la colección sea coherente en ambos lugares y que no haya cambios que impidan que webligth la muestre correctamente.',
      'en':
          'Si se han realizado cambios en la estructura de la colección en la base de datos, como la eliminación o modificación de campos, puede afectar cómo se muestra en webligth. Asegúrate de que la estructura de la colección sea coherente en ambos lugares y que no haya cambios que impidan que webligth la muestre correctamente.',
    },
    '0kpyb5wj': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    'z62svs16': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I11Comercios
  {
    'ovihov6y': {
      'es': '1',
      'en': '1',
    },
    '82bmf0hm': {
      'es': '2',
      'en': '2',
    },
    'hcz6eb80': {
      'es': '3',
      'en': '3',
    },
    'rg4j6x4g': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    'atksotgy': {
      'es': 'Registrar',
      'en': 'Register',
    },
    'wcphyit5': {
      'es': 'E-mail',
      'en': 'Email',
    },
    'o3ihsjq4': {
      'es': 'Confirmar E-mail',
      'en': 'Confirm Email',
    },
    'crwzzre4': {
      'es': 'Contraseña',
      'en': 'Password',
    },
    'pb42jjom': {
      'es': 'Confirmar Contraseña',
      'en': 'Confirm Password',
    },
    'it4nz4le': {
      'es': 'Acepto los términos y condiciones',
      'en': 'Accept the terms and conditions',
    },
    'mzsx4qqs': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et.Lorem ipsum....Lorem ipsum dolor sit amet consectetur ',
      'en':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et.Lorem ipsum....Lorem ipsum dolor sit amet consectetur ',
    },
    'z89yv8ak': {
      'es': '¿Ya tenés cuenta?',
      'en': 'Have Account?',
    },
    '7vy5r5z7': {
      'es': 'Ingresá acá',
      'en': '',
    },
    'kqyn5qar': {
      'es': 'CONTINUAR',
      'en': '',
    },
    'iyc2m8n9': {
      'es': 'Home',
      'en': '',
    },
  },
  // errorregistro
  {
    '4xs5ag8e': {
      'es': '1',
      'en': '1',
    },
    '32mihb49': {
      'es': '2',
      'en': '2',
    },
    '786bcyth': {
      'es': '3',
      'en': '3',
    },
    '4l3c570q': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    '4dunajnj': {
      'es': 'Registrar',
      'en': 'Registrar',
    },
    'gh49n5fw': {
      'es': 'E-mail',
      'en': 'E-mail',
    },
    'q8sfgrdq': {
      'es': 'Confirmar Email',
      'en': 'Confirmar Email',
    },
    'losfdnsf': {
      'es': 'Contraseña',
      'en': 'Contraseña',
    },
    'usbk6q98': {
      'es': 'Confirmar Contraseña',
      'en': 'Confirmar Contraseña',
    },
    'g2yrzeye': {
      'es': 'Acepto los términos y condiciones',
      'en': 'Acepto los términos y condiciones',
    },
    'nml0w574': {
      'es': '¿Ya tenés cuenta?',
      'en': '¿Ya tenés cuenta?',
    },
    'fz8njzh4': {
      'es': 'Ingresá acá',
      'en': 'Ingresá acá',
    },
    'rfr3l70z': {
      'es': 'CONTINUAR',
      'en': 'CONTINUAR',
    },
    'vp7g62qv': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I12RegistrarComercio2
  {
    '4an6um2f': {
      'es': '1',
      'en': '1',
    },
    'a1rx3ldz': {
      'es': '2',
      'en': '2',
    },
    '5a94gpds': {
      'es': '3',
      'en': '3',
    },
    'xi2gnrlg': {
      'es': 'Registrar',
      'en': 'Register',
    },
    'j6x6osr0': {
      'es': 'Nombre del comercio',
      'en': 'Trade Name',
    },
    'mfgksfev': {
      'es': 'Nombre y apellido del encargado',
      'en': 'First and last name of the manager',
    },
    'i055cyxr': {
      'es': 'Categoria',
      'en': 'Category',
    },
    'ttva26fg': {
      'es': 'Codigo Promocional (opcional)',
      'en': 'Promotional Code (Optional)',
    },
    '9gc8jwwg': {
      'es': 'Ubicacion',
      'en': 'Location',
    },
    '7hxnsh1r': {
      'es': 'Descripción del comercio',
      'en': 'Trade Description',
    },
    '8ltnpvhq': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    '529wkzzv': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I16RegistrarComercio3
  {
    'opkjnuic': {
      'es': '1',
      'en': '1',
    },
    '6vh4ncqy': {
      'es': '2',
      'en': '2',
    },
    'lf2m13h3': {
      'es': '3',
      'en': '3',
    },
    'pcucad01': {
      'es': 'Registrar',
      'en': 'Register',
    },
    'pjcsosab': {
      'es': 'Instagram',
      'en': 'Instagram',
    },
    'z5mzwie6': {
      'es': 'Tik Tok',
      'en': 'Tik Tok',
    },
    'y7nasez7': {
      'es': 'YouTube',
      'en': 'YouTube',
    },
    's29zvp6x': {
      'es': 'Twich',
      'en': 'Twich',
    },
    '30gq87u4': {
      'es': 'Imágenes de tu comercio',
      'en': 'Trade Photos',
    },
    'yzhoj8e5': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    'osnmehml': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // op1
  {
    'gaa5uivs': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    '1oqm9s4o': {
      'es': 'Membresías',
      'en': 'Memberships',
    },
    'og8wzcyu': {
      'es': 'Oro',
      'en': 'Oro',
    },
    'b94wd4sz': {
      'es': '\$50',
      'en': '\$50',
    },
    'fx0gmmy0': {
      'es': '/mes',
      'en': '/mes',
    },
    'uu8c25na': {
      'es': '30 influencers',
      'en': '30 influencers',
    },
    'lh830xy1': {
      'es': 'Beneficios',
      'en': 'Beneficios',
    },
    'ypjv4ksv': {
      'es': 'Beneficios',
      'en': 'Beneficios',
    },
    'y5dhf1vn': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    'y0ybyfmr': {
      'es': 'Platinum',
      'en': 'Platinum',
    },
    '84gmjf7a': {
      'es': '\$100',
      'en': '\$100',
    },
    'dvwh1sx6': {
      'es': '/mes',
      'en': '/mes',
    },
    'v1jdpqc1': {
      'es': '100 influencers',
      'en': '100 influencers',
    },
    'znzxb7hn': {
      'es': 'Beneficios',
      'en': 'Beneficios',
    },
    'tuyzusj3': {
      'es': 'Beneficios',
      'en': 'Beneficios',
    },
    'zlucu038': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    'eou9drnq': {
      'es': 'Home',
      'en': '',
    },
  },
  // I18Membresias
  {
    'izp626fn': {
      'es': 'Membresías',
      'en': 'Memberships',
    },
    '5jvi7m81': {
      'es': 'Ver Detalles',
      'en': 'View Details',
    },
    'enht6f8h': {
      'es': 'Lo Quiero',
      'en': 'I want it',
    },
    'ntn892il': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I156Bienvenido
  {
    '8ogoha6w': {
      'es': 'Iniciar Sesión',
      'en': 'Log in',
    },
    'g1vfslkh': {
      'es': 'E-mail',
      'en': 'Email',
    },
    'oaynr50t': {
      'es': 'Contraseña',
      'en': 'Password',
    },
    'utxn07nd': {
      'es': 'Olvide mi contraseña',
      'en': 'Forgot my Password',
    },
    'jflqywpb': {
      'es': 'INICIAR SESION',
      'en': 'LOG IN',
    },
    'ckbv9pvw': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I21Iniciarsesion
  {
    't88melon': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    'zs9u8j3c': {
      'es': 'Iniciar Sesión',
      'en': 'Log In',
    },
    'jsbl64m3': {
      'es': 'E-mail',
      'en': 'Email',
    },
    'd2aem5lc': {
      'es': 'Olvidé mi mail',
      'en': 'Forgor my Email',
    },
    'jezr60ki': {
      'es': 'Contraseña',
      'en': 'Password',
    },
    'rfzstie9': {
      'es': 'Olvide mi contraseña',
      'en': 'Forgor my Password',
    },
    'jli1zjmc': {
      'es': 'INICIAR SESION',
      'en': 'LOG IN',
    },
    '0afavz1d': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I23cambiarpass
  {
    'rcht8262': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    'a7v44pzj': {
      'es': 'Cambiar Contraseña',
      'en': 'Chage Password',
    },
    'ecmpuhhv': {
      'es': 'E-mail',
      'en': 'Email',
    },
    'll5yb30v': {
      'es': 'ENVIAR CÓDIGO',
      'en': 'SEND CODE',
    },
    'swairmkr': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I150verificarcodigo
  {
    'qpbg6ydw': {
      'es': 'COMERCIO',
      'en': 'COMERCIO',
    },
    'ecivmzyv': {
      'es': 'Cambiar Contraseña',
      'en': 'Cambiar Contraseña',
    },
    'ql92nfz2': {
      'es': 'REENVIAR CÓDIGO',
      'en': 'REENVIAR CÓDIGO',
    },
    'b9ii6p9w': {
      'es': '¿No te llegó el mail? Contactarme \ncon ',
      'en': '¿No te llegó el mail? Contactarme \ncon ',
    },
    'm95vaxcw': {
      'es': 'soporte técnico',
      'en': 'soporte técnico',
    },
    'ljg4tsa4': {
      'es': 'ENVIAR CÓDIGO',
      'en': 'ENVIAR CÓDIGO',
    },
    'gyb20up5': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I30nuevapass
  {
    't5xzw8cb': {
      'es': 'COMERCIO',
      'en': 'COMERCIO',
    },
    'reqvmhkp': {
      'es': 'Nueva Contraseña',
      'en': 'Nueva Contraseña',
    },
    'lrb6tl60': {
      'es': 'Contraseña',
      'en': 'Contraseña',
    },
    'kr3upoa8': {
      'es': 'Nueva Contraseña',
      'en': 'Nueva Contraseña',
    },
    '27o4fqsv': {
      'es': 'CONFIRMAR',
      'en': 'CONFIRMAR',
    },
    'cpis4sle': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I155iniciarsesion
  {
    'mjz4x4en': {
      'es': 'COMERCIO',
      'en': 'COMERCIO',
    },
    '8ikdls51': {
      'es': 'Iniciar Sesión',
      'en': 'Iniciar Sesión',
    },
    'ddb2o6z5': {
      'es': 'E-mail',
      'en': 'E-mail',
    },
    'fr0aou2t': {
      'es': 'Olvidé mi mail',
      'en': 'Olvidé mi mail',
    },
    'j6kk7sds': {
      'es': 'Contraseña',
      'en': 'Contraseña',
    },
    'f2zm2kt4': {
      'es': 'Olvide mi contraseña',
      'en': 'Olvide mi contraseña',
    },
    '42p643ep': {
      'es': 'INICIAR SESION',
      'en': 'INICIAR SESION',
    },
    'eqqubuth': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I191ComercioBienvenido
  {
    '7e256607': {
      'es': '¡Bienvenido!',
      'en': '¡Bienvenido!',
    },
    '7a36l1ul': {
      'es': 'Subí una nueva oferta       ',
      'en': 'Uploaded a new offer',
    },
    '4yfcikki': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // op5
  {
    'gfdf2dzp': {
      'es': 'COMERCIO',
      'en': 'COMERCIO',
    },
    '1mddz84d': {
      'es': 'Membresías',
      'en': 'Membresías',
    },
    '5enz79l1': {
      'es': 'Oro',
      'en': 'Oro',
    },
    '7ehjoxyp': {
      'es': '\$50',
      'en': '\$50',
    },
    'gcn1ua96': {
      'es': '/mes',
      'en': '/mes',
    },
    'iyoutgzk': {
      'es': '30 influencers',
      'en': '30 influencers',
    },
    'x43qc8jo': {
      'es': 'Beneficios',
      'en': 'Beneficios',
    },
    'i8bkp1s2': {
      'es': 'Beneficios',
      'en': 'Beneficios',
    },
    'gtw8fvn4': {
      'es': 'CONTINUAR',
      'en': 'CONTINUAR',
    },
    'dqwxuybg': {
      'es': 'Platinum',
      'en': 'Platinum',
    },
    'ato3sghj': {
      'es': '\$100',
      'en': '\$100',
    },
    '7eh91d9q': {
      'es': '/mes',
      'en': '/mes',
    },
    'tkd7557w': {
      'es': '100 influencers',
      'en': '100 influencers',
    },
    'myet17fq': {
      'es': 'Beneficios',
      'en': 'Beneficios',
    },
    '1c718orp': {
      'es': 'Beneficios',
      'en': 'Beneficios',
    },
    '6qxr0xd6': {
      'es': 'CONTINUAR',
      'en': 'CONTINUAR',
    },
    '1mlj11gt': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I172oro
  {
    'gsk89h3k': {
      'es': 'COMERCIO',
      'en': '',
    },
    'd2na4k4w': {
      'es': 'Membresías',
      'en': '',
    },
    'pdg5ejxn': {
      'es': 'Método de pago',
      'en': '',
    },
    'cpf5fipj': {
      'es': 'Mensual 5% off',
      'en': '',
    },
    '9lvindz1': {
      'es': 'Trimestral 20% off',
      'en': '',
    },
    'mxcv1d89': {
      'es': 'Anual 50% off',
      'en': '',
    },
    'aofupgkd': {
      'es': 'Pago',
      'en': '',
    },
    'efpu2cg1': {
      'es': 'latinoamerica',
      'en': '',
    },
    '4bd6laas': {
      'es': 'Global',
      'en': '',
    },
    '97yyrex0': {
      'es': 'CONTINUAR',
      'en': '',
    },
    'vvcdqpbb': {
      'es': 'Home',
      'en': '',
    },
  },
  // I187bienvenido
  {
    'zhozyark': {
      'es': 'LOGO',
      'en': 'LOGO',
    },
    'bfytz9ge': {
      'es': '¡Bienvenido!',
      'en': 'Welcome!',
    },
    '8b19f0b1': {
      'es': 'Subí una nueva oferta',
      'en': 'Uploaded a new offer',
    },
    'rgjfoj7z': {
      'es': 'Comercio',
      'en': 'Trade',
    },
    'dusatjox': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I107Crearnuevaoferta2
  {
    'qd817vwe': {
      'es': 'Nueva oferta',
      'en': 'New Offer',
    },
    'nakgys59': {
      'es': 'Descripción del beneficio',
      'en': 'Benefit Description',
    },
    '5xvlom3g': {
      'es': 'CREAR',
      'en': 'CREATE',
    },
    'jyifx2g6': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I77
  {
    'dep7v5mr': {
      'es': 'Crear una nueva oferta',
      'en': 'New Offer',
    },
    '66gh667i': {
      'es': 'Fecha/Hora',
      'en': 'Data/Time',
    },
    'lwu998u6': {
      'es': 'Cantidad de influencer ',
      'en': 'Quantity Influencer',
    },
    'zdfrybg2': {
      'es': 'Ubicacion',
      'en': 'Location',
    },
    'tmol1lv0': {
      'es': 'Descripción del trabajo',
      'en': 'Work Description',
    },
    'arpxgxg9': {
      'es': 'Cargar imágenes (opcional)',
      'en': 'Upload image(optional)',
    },
    '64ldl9x5': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    'h1mrkidl': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I196Foto
  {
    '2lvbkoz1': {
      'es': 'Kristin Watson, 24',
      'en': 'Kristin Watson, 24',
    },
    'ew2eefud': {
      'es': 'Modelo',
      'en': 'Modelo',
    },
    '9wc19e68': {
      'es': 'Ususario No Disponible',
      'en': '',
    },
    'culxz6vn': {
      'es': 'Juan Carlo, 61',
      'en': 'Juan Carlo, 61',
    },
    'nv4u8fwj': {
      'es': 'Modelo',
      'en': 'Modelo',
    },
    'lcwpb0v7': {
      'es': 'Kristin Watson, 24',
      'en': 'Kristin Watson, 24',
    },
    'x3mf0wp4': {
      'es': 'Modelo',
      'en': 'Modelo',
    },
    '5in9xmfy': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I170
  {
    'vwxe8mid': {
      'es': 'Kristin Watson',
      'en': 'Kristin Watson',
    },
    '5bd2uu8n': {
      'es': 'Mega influencer',
      'en': 'Mega influencer',
    },
    'tvy7mj7z': {
      'es': '2km',
      'en': '2km',
    },
    'vnuq0zk0': {
      'es': 'COMIDA',
      'en': 'FOOD',
    },
    'qqk5cnon': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et.',
      'en':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et.',
    },
    'qg089w61': {
      'es': 'Lorem ipsum dolor sit amet consectetur!\n',
      'en': 'Lorem ipsum dolor sit amet consectetur!\n',
    },
    'ixqp5hwz': {
      'es': 'Abonos',
      'en': 'Abonos',
    },
    'qc44tcnf': {
      'es': 'Tik Tok  ',
      'en': 'Tik To',
    },
    'wekca495': {
      'es': '10.000 \$',
      'en': '10.000 \$',
    },
    'j4nc92sf': {
      'es': 'Twitch',
      'en': 'Twitch',
    },
    'dgp2wghw': {
      'es': '20.000 \$',
      'en': '20.000 \$',
    },
    'ax88o0r0': {
      'es': 'SOLICITAR',
      'en': 'SOLICITAR',
    },
    'n5wzznyi': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // op3
  {
    '0snk5ka1': {
      'es': 'COMERCIO',
      'en': 'COMERCIO',
    },
    '7znsqee6': {
      'es': 'Membresías',
      'en': 'Membresías',
    },
    '7nhu1vtx': {
      'es': 'Platinum',
      'en': 'Platinum',
    },
    'kxnkj6dl': {
      'es': '\$100',
      'en': '\$100',
    },
    '4tu1fnqc': {
      'es': '/mes',
      'en': '/mes',
    },
    'avhjbkan': {
      'es': '100 influencers',
      'en': '100 influencers',
    },
    'y0xmikke': {
      'es': 'CONTINUAR',
      'en': 'CONTINUAR',
    },
    'bp0utk7n': {
      'es': 'Oro',
      'en': 'Oro',
    },
    'xjzdgoen': {
      'es': '\$25',
      'en': '\$25',
    },
    '76srzi9e': {
      'es': '/mes',
      'en': '/mes',
    },
    'h6jw49qs': {
      'es': '50 influencers',
      'en': '50 influencers',
    },
    'adaj72zx': {
      'es': 'CONTINUAR',
      'en': 'CONTINUAR',
    },
    'a5ush6zy': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I166
  {
    'yquba9xh': {
      'es': 'COMERCIO',
      'en': '',
    },
    'l7bs7wtu': {
      'es': 'Membresías',
      'en': '',
    },
    'l51ru6go': {
      'es': 'Platinum',
      'en': '',
    },
    'cv58q9az': {
      'es': '100 \$',
      'en': '',
    },
    'rpx7cji1': {
      'es': '100 Influencers',
      'en': '',
    },
    '1p8v510b': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae mattis tellus..',
      'en': '',
    },
    'xqf7s2d6': {
      'es': 'UPGRADE',
      'en': '',
    },
    'edarxtu7': {
      'es': 'Home',
      'en': '',
    },
  },
  // I197MegaInfluencer
  {
    '4o0xs69z': {
      'es': 'Buscar...',
      'en': 'Buscar...',
    },
    's43jxig4': {
      'es': 'Mega Influencers',
      'en': 'Mega Influencers',
    },
    'vv7mt10o': {
      'es': 'Abs +  Gluteos',
      'en': 'Abs +  Gluteos',
    },
    'wnckbbxo': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    'tzmvk4ed': {
      'es': 'Kristin Watson',
      'en': 'Kristin Watson',
    },
    'o40n0ymf': {
      'es': '2km',
      'en': '2km',
    },
    'qumzglce': {
      'es': 'Abs +  Gluteos',
      'en': 'Abs +  Gluteos',
    },
    '1enmdrqp': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    't8vvt0qa': {
      'es': 'CHAYANE AZUL',
      'en': 'CHAYANE AZUL',
    },
    '7eszbtxw': {
      'es': '2km',
      'en': '2km',
    },
    '2ksus7hq': {
      'es': 'Abs +  Gluteos',
      'en': 'Abs +  Gluteos',
    },
    'm0nm6jii': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    'rdxvo9xl': {
      'es': 'ROMINA GROL',
      'en': 'ROMINA GROL',
    },
    'c444n7v4': {
      'es': '2km',
      'en': '2km',
    },
    '86v4zhvl': {
      'es': 'Abs +  Gluteos',
      'en': 'Abs +  Gluteos',
    },
    'awp0hptq': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    'j97r4tfe': {
      'es': 'Kristin Watson',
      'en': 'Kristin Watson',
    },
    '9id0xw7y': {
      'es': '2km',
      'en': '2km',
    },
    'bghhf1um': {
      'es': 'Abs +  Gluteos',
      'en': 'Abs +  Gluteos',
    },
    '0sfby590': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    'xmdz2hx8': {
      'es': 'CHAYANE AZUL',
      'en': 'CHAYANE AZUL',
    },
    'pix2lhie': {
      'es': '2km',
      'en': '2km',
    },
    'y0c3l9bp': {
      'es': 'Abs +  Gluteos',
      'en': 'Abs +  Gluteos',
    },
    'llah3p2u': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    '5dcmrps4': {
      'es': 'ROMINA GROL',
      'en': 'ROMINA GROL',
    },
    'uavigo03': {
      'es': '2km',
      'en': '2km',
    },
    'pvmble3e': {
      'es': 'Abs +  Gluteos',
      'en': 'Nano influencer',
    },
    'c3u5if3o': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    'qg8kyiw7': {
      'es': 'Kristin Watson',
      'en': 'Kristin Watson',
    },
    '796unsfh': {
      'es': '2km',
      'en': '2km',
    },
    'z71pscqg': {
      'es': 'Abs +  Gluteos',
      'en': 'Abs +  Gluteos',
    },
    'ufcwm0mb': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    'citz7l4r': {
      'es': 'CHAYANE AZUL',
      'en': 'CHAYANE AZUL',
    },
    '9cle7e38': {
      'es': '2km',
      'en': '2km',
    },
    'qckjubce': {
      'es': 'Abs +  Gluteos',
      'en': 'Abs +  Gluteos',
    },
    'ugrz3sh5': {
      'es': 'Nano influencer',
      'en': 'Nano influencer',
    },
    'oshu6eho': {
      'es': 'ROMINA GROL',
      'en': 'ROMINA GROL',
    },
    'dtxqr1g3': {
      'es': '2km',
      'en': '2km',
    },
    'tqjediu4': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I112inicio
  {
    '9rw5pmsp': {
      'es': 'Comida',
      'en': 'Comida',
    },
    'rd6t081k': {
      'es': '2Km',
      'en': '2Km',
    },
    'sg402o6a': {
      'es': 'Fitness',
      'en': 'Fitness',
    },
    'm5mu7mt9': {
      'es': 'Drinks + entrada',
      'en': 'Drinks + entrada',
    },
    'h7ubh0dr': {
      'es': 'De 18:00 - 19:30pm',
      'en': 'De 18:00 - 19:30pm',
    },
    'ul98jrum': {
      'es': 'NEGRONI',
      'en': 'NEGRONI',
    },
    'hyp06fc6': {
      'es': '2Km',
      'en': '2Km',
    },
    'ez5liq5h': {
      'es': 'Drinks + entrada',
      'en': 'Drinks + entrada',
    },
    'vkzmq69f': {
      'es': 'De 18:00 - 19:30pm',
      'en': 'De 18:00 - 19:30pm',
    },
    '2q9znveq': {
      'es': 'NEGRONI',
      'en': 'NEGRONI',
    },
    'juhvdeuz': {
      'es': '2Km',
      'en': '2Km',
    },
    '5q5rmolx': {
      'es': 'Drinks + entrada',
      'en': 'Drinks + entra',
    },
    'pyqfsim7': {
      'es': 'De 18:00 - 19:30pm',
      'en': 'De 18:00 - 19:30pm',
    },
    '8hdumdnd': {
      'es': 'NEGRONI',
      'en': 'NEGRONI',
    },
    'kr56uf7n': {
      'es': '2Km',
      'en': '2Km',
    },
    'ws0i6y78': {
      'es': 'Buenos Aires',
      'en': 'Buenos Aires',
    },
    'a76mp70h': {
      'es': 'PUBLICAR UNA NUEVA OFERTA',
      'en': 'PUBLICAR UNA NUEVA OFERTA',
    },
    'zuyz6jbi': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I25misofertas
  {
    'zr4waxox': {
      'es': 'Drinks + entrada',
      'en': 'Drinks + entrada',
    },
    'o0gr7cxw': {
      'es': 'Pasá entre las 18:00 - 19:30pm',
      'en': 'Pasá entre las 18:00 - 19:30pm',
    },
    'unnhavqz': {
      'es': '2km',
      'en': '2km',
    },
    'u2lj4wdv': {
      'es': 'NEGRONI',
      'en': 'NEGRONI',
    },
    '1mj9w8n7': {
      'es': 'Av. Santa Fe 19888',
      'en': 'Av. Santa Fe 19888',
    },
    's7bs8187': {
      'es': 'Código - AD1234 ',
      'en': 'Código - AD1234 ',
    },
    '1kos67zz': {
      'es':
          'Disfrutá una porción de pan o ensalada de \ncortesía + una Provoleta Negroni o unos\nLangostinos de Roca o unas Papas Bravas + 2 \ntragos a elección.',
      'en':
          'Disfrutá una porción de pan o ensalada de \ncortesía + una Provoleta Negroni o unos\nLangostinos de Roca o unas Papas Bravas + 2 \ntragos a elección.',
    },
    'z03yofmp': {
      'es': 'Dejanos tu reseña en Google!\n',
      'en': 'Dejanos tu reseña en Google!',
    },
    'p4axl1cv': {
      'es': 'ACEPTAR',
      'en': 'ACEPTAR',
    },
    '568ssvys': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I116ofertasrealizadas
  {
    '1umxfq18': {
      'es': 'Clase de abdominales',
      'en': 'Clase de abdominales',
    },
    '4lsxlvr9': {
      'es': 'Pasá entre 16:00 - 17:30pm',
      'en': 'Pasá entre 16:00 - 17:30pm',
    },
    'oigodd6d': {
      'es': '2km',
      'en': '2km',
    },
    'cr45folr': {
      'es': 'SPORT CLUB',
      'en': 'SPORT CLUB',
    },
    'is22bqd6': {
      'es': 'Av. Santa Fe 19888',
      'en': 'Av. Santa Fe 19888',
    },
    'c1ihfh5r': {
      'es': 'Brand Partnership',
      'en': 'Brand Partnership',
    },
    'ajvhlbrl': {
      'es': 'Realizada',
      'en': 'Realizada',
    },
    'msj5nufv': {
      'es': 'Código - AD1234 ',
      'en': 'Código - AD1234 ',
    },
    'xs006v9s': {
      'es':
          'Vení a entrenar. Sumate a una de nuestras clases de gimnasia localizada de 45 minutos. Te esperamos!',
      'en':
          'Vení a entrenar. Sumate a una de nuestras clases de gimnasia localizada de 45 minutos. Te esperamos!',
    },
    'qzty54yw': {
      'es': 'Dejanos tu reseña en Google!\n',
      'en': 'Dejanos tu reseña en Google!',
    },
    'awo3bcdz': {
      'es': 'Influencers que formaron parte',
      'en': 'Influencers que formaron parte',
    },
    'rowjgor9': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I184
  {
    '4zhwlsjw': {
      'es': 'Clase de abdominales',
      'en': 'Clase de abdominales',
    },
    '6mdvz05b': {
      'es': 'Pasá entre 16:00 - 17:30pm',
      'en': 'Pasá entre 16:00 - 17:30pm',
    },
    '2t3cwg6l': {
      'es': '2km',
      'en': '2km',
    },
    'crcr5wwx': {
      'es': 'SPORT CLUB',
      'en': 'SPORT CLUB',
    },
    'lgitb9r4': {
      'es': 'Av. Santa Fe 19888',
      'en': 'Av. Santa Fe 19888',
    },
    'xweglqgs': {
      'es': 'Brand Partnership',
      'en': 'Brand Partnership',
    },
    'y0gko3a1': {
      'es': 'Realizada',
      'en': 'Realizada',
    },
    'pxcauqu4': {
      'es': 'Código - AD1234 ',
      'en': 'Código - AD1234 ',
    },
    'xqfzmro2': {
      'es':
          'Vení a entrenar. Sumate a una de nuestras clases de gimnasia localizada de 45 minutos. Te esperamos!',
      'en':
          'Vení a entrenar. Sumate a una de nuestras clases de gimnasia localizada de 45 minutos. Te esperamos!',
    },
    'q2bgusls': {
      'es': 'Dejanos tu reseña en Google!\n',
      'en': 'Dejanos tu reseña en Google!',
    },
    '28yx18y3': {
      'es': 'Influencers que formaron parte',
      'en': 'Influencers que formaron parte',
    },
    'ld8fv6et': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // op4
  {
    'r1kbe8r4': {
      'es': 'COMERCIO',
      'en': 'COMERCIO',
    },
    'b4r0gr0a': {
      'es': 'Membresías',
      'en': 'Membresías',
    },
    '8urypai0': {
      'es': 'Oro',
      'en': 'Oro',
    },
    '75104qhb': {
      'es': '\$50',
      'en': '\$50',
    },
    'guxppu4m': {
      'es': '/mes',
      'en': '/mes',
    },
    '7s8jradn': {
      'es': '30 influencers',
      'en': '30 influencers',
    },
    'ifnfifek': {
      'es': 'CONTINUAR',
      'en': 'CONTINUAR',
    },
    'fmv7t06h': {
      'es': 'Platinum',
      'en': 'Platinum',
    },
    'b112mq99': {
      'es': '\$100',
      'en': '\$100',
    },
    'pnev6hjm': {
      'es': '/mes',
      'en': '/mes',
    },
    '86w2rhdd': {
      'es': '100 influencers',
      'en': '100 influencers',
    },
    'wk4grx5t': {
      'es': 'CONTINUAR',
      'en': 'CONTINUAR',
    },
    'dmjinggm': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I194Oro
  {
    'hkmb3mf3': {
      'es': 'COMERCIO',
      'en': 'COMERCIO',
    },
    'lq6qnr9w': {
      'es': 'Membresías',
      'en': 'Membresías',
    },
    'xsxh1dae': {
      'es': 'Oro',
      'en': 'Oro',
    },
    'f9z5h1uo': {
      'es': '50 \$',
      'en': '50 \$',
    },
    '6utdmu7h': {
      'es': '30 Influencers',
      'en': '30 Influencers',
    },
    '075jj52n': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae mattis tellus..',
      'en':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae mattis tellus..',
    },
    'goj4v46c': {
      'es': 'Método de pago',
      'en': 'Método de pago',
    },
    'qilrov6f': {
      'es': 'Pago',
      'en': 'Pago',
    },
    '7l0vw7hq': {
      'es': 'Sincronizar',
      'en': 'Sincronizar',
    },
    'y4pv5d8k': {
      'es': 'Sincronizar',
      'en': 'Sincronizar',
    },
    'rdhq7weg': {
      'es': 'UPGRADE',
      'en': 'UPGRADE',
    },
    '2wfnq14q': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I193oroupgrade
  {
    'lpyxyjs0': {
      'es': 'COMERCIO',
      'en': '',
    },
    '7pxvjojq': {
      'es': 'Membresías',
      'en': '',
    },
    '4ac9tm6x': {
      'es': 'Oro',
      'en': '',
    },
    'a0dew4sm': {
      'es': '50 \$',
      'en': '',
    },
    '7lvo1pv9': {
      'es': '30 Influencers',
      'en': '',
    },
    'ldfxw1au': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae mattis tellus..',
      'en': '',
    },
    'k6szmh6j': {
      'es': 'UPGRADE',
      'en': '',
    },
    'mcq57ib8': {
      'es': 'Home',
      'en': '',
    },
  },
  // I168
  {
    '0hc8zrdk': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    'wdh39kjm': {
      'es': 'Membresías',
      'en': 'Memberships',
    },
    '1xun8dam': {
      'es': 'Platinum',
      'en': 'Platinum',
    },
    'kpu6y5io': {
      'es': '100 \$',
      'en': '100 \$',
    },
    '5fg82ytf': {
      'es': '30 Influencers',
      'en': '30 Influencers',
    },
    'gia4ione': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae mattis tellus..',
      'en':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae mattis tellus..',
    },
    '6fb6gd2w': {
      'es': 'Método de pago',
      'en': 'Método de pago',
    },
    'mxrszkrw': {
      'es': 'Pago',
      'en': 'Pago',
    },
    'qpmaz43t': {
      'es': 'Sincronizar',
      'en': 'Sincronizar',
    },
    '9zklrnbq': {
      'es': 'Sincronizar',
      'en': 'Sincronizar',
    },
    'r7abscu8': {
      'es': 'UPGRADE',
      'en': 'UPGRADE',
    },
    'itici4zb': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I28Chat
  {
    'ozsu6lgf': {
      'es': 'Atención al Cliente',
      'en': '',
    },
    'dunyu2tt': {
      'es': 'Martes, 15',
      'en': '',
    },
    'qitzg82h': {
      'es':
          'Ey! ¿Cómo podemos ayudarte?\nSi estás teniendo problemas\ncon la app mandá:',
      'en': '',
    },
    'wpz9mi2s': {
      'es': '. ',
      'en': '',
    },
    'np79e2s9': {
      'es': '1. Tengo un problema\ncon la oferta.',
      'en': '',
    },
    'jrqbgkfz': {
      'es': '8.30pm',
      'en': '',
    },
    '5ox9cdkd': {
      'es':
          'Hola! ¿Qué tal? Sí,\ngracias! 1. tengo un\nproblema con la\noferta.',
      'en': '',
    },
    'q396vcc4': {
      'es': '8.33pm',
      'en': '',
    },
    '1hrgtg0f': {
      'es': 'Escribir...',
      'en': '',
    },
    '6yspv4cw': {
      'es': 'Home',
      'en': '',
    },
  },
  // I201chatvacio
  {
    'ewhwe5b8': {
      'es': 'Escribir...',
      'en': 'Escribir...',
    },
    '4b5fqi3p': {
      'es': 'Atención al Cliente',
      'en': 'Atención al Cliente',
    },
    'o9vrz7jx': {
      'es': 'Martes, 15',
      'en': 'Martes, 15',
    },
    'chwc414q': {
      'es': 'Todavía no tenés mensajes!',
      'en': 'Todavía no tenés mensajes',
    },
    'vpb6xumk': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I136Acciones
  {
    'e6hlsxyn': {
      'es': 'Calendario',
      'en': 'Calendario',
    },
    '73dc0m01': {
      'es': 'Acciones del mes',
      'en': 'Acciones del mes',
    },
    'hrbixviz': {
      'es': '2 de septiembre',
      'en': '2 de septiembre',
    },
    't7bvuj1w': {
      'es': '2021',
      'en': '2021',
    },
    'c51x86cg': {
      'es': '10:00-13:00',
      'en': '10:00-13:00',
    },
    '4fdobcak': {
      'es': 'Acción instagram -  Fiesta',
      'en': 'Acción instagram -  Fiesta',
    },
    '2gpl7ffk': {
      'es': '3 historias , ropa fiesta',
      'en': '3 historias , ropa fiesta',
    },
    'rf2f6skf': {
      'es': '14:00-15:00',
      'en': '14:00-15:00',
    },
    'q3d5cnxw': {
      'es': 'Tik Tok - GRWM',
      'en': 'Tik Tok - GRWM',
    },
    'es2fkkr6': {
      'es': 'Define the problem or question that....',
      'en': 'Define the problem or question that....',
    },
    'n7g1qo59': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I40notificacionesComercio
  {
    'kwn8ey8t': {
      'es': 'Notificaciones',
      'en': 'Notificaciones',
    },
    '8jdb3lck': {
      'es': 'Borrar Historial',
      'en': 'Borrar Historia',
    },
    'oany34xf': {
      'es': 'Ahora sos Mega Influencer!',
      'en': '',
    },
    'knj7g8wt': {
      'es': '12:00',
      'en': '',
    },
    'gxrs59ol': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I203sinnotificaciones
  {
    'j3r0o0zn': {
      'es': 'Notificaciones',
      'en': '',
    },
    'jl9n5d94': {
      'es': 'No tenés notificaciones!',
      'en': '',
    },
    'dzjfmbn6': {
      'es': 'Home',
      'en': '',
    },
  },
  // I140ajustes
  {
    '9t91mipw': {
      'es': 'CERRAR SESIÓN',
      'en': 'LOG OUT',
    },
    'hlootydp': {
      'es': 'Ajustes',
      'en': 'Satting',
    },
    'tusbbz93': {
      'es': 'Negroni',
      'en': 'Negroni',
    },
    '4shzrk0d': {
      'es': '@clau.fern.ceo',
      'en': '@clau.fern.ceo',
    },
    'ljyr0v89': {
      'es': 'CEO',
      'en': 'CEO',
    },
    '0tb1bu9q': {
      'es': 'Mi cuenta',
      'en': 'My Account',
    },
    'el6osojt': {
      'es': 'Usuario, contraseña...',
      'en': 'User, password...',
    },
    '6tpbz4cu': {
      'es': 'Atencion al cliente',
      'en': 'Customer Support',
    },
    'yqjegwrj': {
      'es': 'Responde tus preguntas...',
      'en': 'Answer your questions...',
    },
    'g9wwj6kx': {
      'es': 'Ayuda',
      'en': 'Help',
    },
    'ruedi4nj': {
      'es': 'Todas tus dudas...',
      'en': 'All your doubts...',
    },
    'ooo540dz': {
      'es': 'Método de pago',
      'en': 'Payment method',
    },
    'l7fuaf6s': {
      'es': 'La mejor manera de recibir los....',
      'en': 'The best way to receive...',
    },
    't3ngwlje': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I142ajustes2
  {
    'm2utthdu': {
      'es': 'EDITAR',
      'en': 'EDIT',
    },
    '3juaaqtw': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    'j7s3qlwg': {
      'es': 'Mi cuenta',
      'en': 'My Account',
    },
    '0haay6hy': {
      'es': 'Privacidad, seguridad, cambiar email o número',
      'en': 'Privacy, security, change email or number',
    },
    'vpohcwju': {
      'es': 'Negroni',
      'en': 'Negroni',
    },
    '199pamit': {
      'es': 'Información personal',
      'en': 'Personal Information',
    },
    'tivq7nhi': {
      'es': 'Claudia Fernandez',
      'en': 'Claudia Fernandez',
    },
    'j00q6b80': {
      'es': '10/09/2023',
      'en': '10/09/2023',
    },
    'paxwoqzv': {
      'es': '@Clau.fer',
      'en': '@Clau.fer',
    },
    'res8obp2': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    'wehlbodn': {
      'es': 'Ubicación',
      'en': 'Location',
    },
    '7hh5cv4i': {
      'es': 'Monseñor de Andrea 1892',
      'en': 'Monseñor de Andrea 1892',
    },
    'oim9r19p': {
      'es': 'Cambiar contraseña',
      'en': 'Change Password',
    },
    '6z8t0x0v': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I143ajustes3
  {
    '2edkyfqa': {
      'es': 'GUARDAR CAMBIOS',
      'en': 'SAVE CHANGES',
    },
    '6y3dkfc2': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    'z8hazc8g': {
      'es': 'Mi cuenta',
      'en': 'My Account',
    },
    'ach5ojoz': {
      'es': 'Privacidad, seguridad, cambiar email o número',
      'en': 'Privacy, security, change email or number',
    },
    '3kt16jps': {
      'es': 'Negroni',
      'en': 'Negroni',
    },
    'gsa7ldo2': {
      'es': 'Información personal',
      'en': 'personal information',
    },
    'puyddvwd': {
      'es': 'Claudia Fernandez',
      'en': 'Claudia Fernandez',
    },
    '783qk8hy': {
      'es': '10/09/2023',
      'en': '10/09/2023',
    },
    'ul04q3wj': {
      'es': '@Clau.fer',
      'en': '@Clau.fer',
    },
    'hu6te5ey': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    'k5qzdr7j': {
      'es': 'Ubicación',
      'en': 'Location',
    },
    'sosqh6cc': {
      'es': 'Monseñor de Andrea 1892',
      'en': 'Monseñor de Andrea 1892',
    },
    '05hvzeme': {
      'es': 'Cambiar Contraseña',
      'en': 'Change Password',
    },
    '4xwr5hz3': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I186atencionalcliente
  {
    'ldzjg2dv': {
      'es': 'Atención al Cliente',
      'en': 'Atención al Cliente',
    },
    'o73mweb3': {
      'es': 'Martes, 15',
      'en': 'Martes, 15',
    },
    'pww29s3n': {
      'es':
          'Ey! ¿Cómo podemos ayudarte?\nSi estás teniendo problemas\ncon la app mandá:',
      'en':
          'Ey! ¿Cómo podemos ayudarte?\nSi estás teniendo problemas\ncon la app mandá:',
    },
    '9gwbjqxb': {
      'es': '. ',
      'en': '.',
    },
    'eir4sq3j': {
      'es': '1. Tengo un problema\ncon la oferta.',
      'en': '1. Tengo un problema\ncon la oferta.',
    },
    'dw3da9qx': {
      'es': '8.30pm',
      'en': '8.30pm',
    },
    'xcuehvpu': {
      'es':
          'Hola! ¿Qué tal? Sí,\ngracias! 1. tengo un\nproblema con la\noferta.',
      'en':
          'Hola! ¿Qué tal? Sí,\ngracias! 1. tengo un\nproblema con la\noferta.',
    },
    'bo46knba': {
      'es': '8.33pm',
      'en': '',
    },
    'm4865yy4': {
      'es': 'Escribir...',
      'en': '',
    },
    '29sd0tly': {
      'es': 'Home',
      'en': '',
    },
  },
  // I145ayuda
  {
    'q9d2f5fr': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    'b4ziimnm': {
      'es': 'Ayuda',
      'en': 'Help',
    },
    'h62gl7px': {
      'es': 'Buscar...',
      'en': 'Search..',
    },
    '6rfqzfip': {
      'es': 'Tengo un problema',
      'en': 'I Have a Problem',
    },
    'nek8a53l': {
      'es': 'Estado de la cuenta',
      'en': 'Acount State',
    },
    'nkj6ifnr': {
      'es': 'Privacidad y seguridad',
      'en': 'Privacy & Security',
    },
    'j6hou8ee': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I146tengounproblema
  {
    'x3elvsq8': {
      'es': 'IR A MI CASILLA DE MAIL',
      'en': 'GO TO MY MAIL BOX',
    },
    'n5lilfog': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    '62u9tthf': {
      'es': 'Ayuda',
      'en': 'Help',
    },
    'pcl1652x': {
      'es': 'Tengo un problema',
      'en': 'I have a Problem',
    },
    'n5ix6z32': {
      'es': 'Mandá un mail a info@litapp.com indicando el problema.',
      'en': 'Send an email to info@litapp.com indicating the problem.',
    },
    't8nc4aka': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I149estadodelacuenta
  {
    'tib5290k': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    '36jl20dd': {
      'es': 'Estado de la cuenta',
      'en': 'Acount State',
    },
    '88q722ok': {
      'es': 'Mandá un mail a info@litapp.com indicando el problema.',
      'en': 'Send an email to info@litapp.com indicating the problem.',
    },
    'f5bi22hl': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.',
      'en':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.',
    },
    '9jgv8qx2': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.',
      'en':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.',
    },
    '4glbxvuu': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.',
      'en':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.',
    },
    'uhcj48i6': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I150seguridadyprivacidad
  {
    'sapt89yq': {
      'es': 'Ajustes',
      'en': '',
    },
    '2w1zdnv7': {
      'es': 'Seguridad y Privacidad',
      'en': '',
    },
    'ykrd1ksm': {
      'es':
          'Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Lorem ipsum dolor sit amet consectetur adipiscing elit. Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.\nLorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Lorem ipsum dolor sit amet consectetur adipiscing elit. Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi.',
      'en': '',
    },
    'a5zv12bp': {
      'es': 'Home',
      'en': '',
    },
  },
  // I147ayuda
  {
    '8ldr8asq': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    'ugft25nk': {
      'es': 'Ayuda',
      'en': 'Help',
    },
    'zhwiryh0': {
      'es': 'No me anda el chat...',
      'en': 'The chat doesn\'t work for me...',
    },
    'x3vji07i': {
      'es': 'Tengo un problema',
      'en': 'I have a problem',
    },
    'rxkmp0ek': {
      'es': 'Estado de la cuenta',
      'en': 'Account status',
    },
    'bqn681sz': {
      'es': 'Privacidad y seguridad',
      'en': 'Privacy & Security',
    },
    'qoc1x9ff': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I148ayudanoseencontro
  {
    'gbur879v': {
      'es': 'Ajustes',
      'en': 'Setting',
    },
    'bls5yrfn': {
      'es': 'Ayuda',
      'en': 'Help',
    },
    'ga1m9efw': {
      'es': 'No me anda el chat...',
      'en': 'The chat doesn\'t work for me...',
    },
    '1lzgflkk': {
      'es':
          'No encontramos nada relacionado a tu búsqueda, podés probar reportando el problema',
      'en':
          'We did not find anything related to your search, you can try reporting the problem',
    },
    '1wj30f7z': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I38metododepagocomercio
  {
    'h0fqpeem': {
      'es': 'Ajustes',
      'en': 'Calendar',
    },
    '4ijbhpuh': {
      'es': 'Método de pago',
      'en': 'Payment method',
    },
    'vjywfw73': {
      'es': 'Sincronizar',
      'en': 'Sync',
    },
    'cd4me8dx': {
      'es': 'Sincronizar',
      'en': 'Sync',
    },
    'p1rv0c73': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // A2Inicio
  {
    'n4mvnrax': {
      'es': 'INICIAR SESIÓN',
      'en': 'LOG IN',
    },
    'ltt7bxz8': {
      'es': 'INICIAR SESIÓN',
      'en': 'LOG IN',
    },
    'yakcoo7j': {
      'es': 'USUARIO',
      'en': 'USER',
    },
    '7tttp2ry': {
      'es': 'CONTRASEÑA',
      'en': 'PASSWORD',
    },
    '7paiutal': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // A3Comercio
  {
    '3l6s05iz': {
      'es': 'Comercios',
      'en': 'Trades',
    },
    'mh9ukq53': {
      'es': 'Filtrar por',
      'en': 'Filter by',
    },
    'a0zd4jhu': {
      'es': 'Filtrar por',
      'en': 'Filter by',
    },
    '9a0vjy2h': {
      'es': 'Dia',
      'en': 'Day',
    },
    'mw3nfer8': {
      'es': 'Buscar por iten...',
      'en': 'Search for item...',
    },
    'tvbfvrk0': {
      'es': 'Mes',
      'en': 'Month',
    },
    'h1e499h6': {
      'es': 'Buscar por item...',
      'en': 'Search for an item...',
    },
    'an4gcih5': {
      'es': 'Año',
      'en': 'Year',
    },
    'yd9yw2n0': {
      'es': 'Buscar por item...',
      'en': 'Search for an item...',
    },
    'dhm2dumg': {
      'es': 'Mostrar como',
      'en': 'Show as',
    },
    'fatc8glo': {
      'es': 'NUEVOS COMERCIANTES',
      'en': 'NEW TRADE',
    },
    'c5l8z3r9': {
      'es': '24',
      'en': '24',
    },
    '9gqv59cl': {
      'es': 'en el último mes',
      'en': 'last month',
    },
    'ajdd873x': {
      'es': 'BAJAS',
      'en': 'LOW',
    },
    'rr6dmss4': {
      'es': '24',
      'en': '24',
    },
    'aq4ge67a': {
      'es': 'en el último mes',
      'en': 'last month',
    },
    '3drwc49m': {
      'es': 'NUEVAS SOLICITUDES',
      'en': 'NEW REQUESTS',
    },
    'jhkjh7k2': {
      'es': '24',
      'en': '24',
    },
    'k3kme18t': {
      'es': 'en el último mes',
      'en': 'last month',
    },
    'hqzvhh9c': {
      'es': 'RUBRO MAS CONTRATADO',
      'en': 'JOB MOST HIRED',
    },
    'bk4p37tf': {
      'es': 'MODA',
      'en': 'FASHION',
    },
    'r0smdgf4': {
      'es': 'en el último mes',
      'en': 'last month',
    },
    '8jvzqaq7': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // A7Comercio
  {
    'p3vowlbo': {
      'es': '46 STREET',
      'en': '46 STREET',
    },
    'gfjonpdi': {
      'es': 'Miembro desde 13/09/2022',
      'en': 'Member since 13/09/2022',
    },
    'z5b8cnvv': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    '2nrd450k': {
      'es': 'Contacto',
      'en': 'Contact',
    },
    'vhebixg4': {
      'es': '47street@gmail.com',
      'en': '47street@gmail.com',
    },
    'ush6g30o': {
      'es': '+54 911 60457878',
      'en': '+54 911 60457878',
    },
    'cad0fhlb': {
      'es': 'Membresía',
      'en': 'Memberships',
    },
    '44c45mpy': {
      'es': 'Platinum',
      'en': 'Platinum',
    },
    'bj7b4w5a': {
      'es': 'Campañas creadas',
      'en': 'Campaigns created',
    },
    'im326qjf': {
      'es': 'Ultimo mes',
      'en': 'Last Month',
    },
    '23t5sm76': {
      'es': '30',
      'en': '30',
    },
    'k70c1zq8': {
      'es': 'Ultima semana',
      'en': 'Last Week',
    },
    'jxx73ddw': {
      'es': '30% +',
      'en': '30% +',
    },
    '3nu4cg7g': {
      'es': 'Campañas activas',
      'en': 'Active campaigns',
    },
    'cmdxlus9': {
      'es': '30',
      'en': '30',
    },
    'yqnmvnmx': {
      'es': 'Ultima semana',
      'en': 'Last Week',
    },
    'afybzpe8': {
      'es': '30% +',
      'en': '30% +',
    },
    'of035ofe': {
      'es': 'Historial',
      'en': 'Record',
    },
    '5e2oi3cu': {
      'es': 'Buscar...',
      'en': 'Search...',
    },
    'n1lv3skt': {
      'es': 'Camila mendez ',
      'en': 'Camila mendez ',
    },
    'ux336abh': {
      'es': 'Acción - Stories ',
      'en': 'Acción - Stories ',
    },
    'bf2g5rna': {
      'es': '20/03/2022',
      'en': '20/03/2022',
    },
    '4o71y2zh': {
      'es': 'Campaña de marketing',
      'en': 'Marketing campaign',
    },
    'h7irg50j': {
      'es': 'POR CANJE',
      'en': 'BY CANJE',
    },
    '75jgzelr': {
      'es': 'Cancelaciones',
      'en': 'Cancellations',
    },
    'uj1m1abt': {
      'es': '2/',
      'en': '2/',
    },
    'iu000raa': {
      'es': '3',
      'en': '3',
    },
    '3ljvjfrz': {
      'es': 'Camila mendez ',
      'en': 'Camila mendez ',
    },
    't5jzlciv': {
      'es': 'Acción - Stories ',
      'en': 'Acción - Stories ',
    },
    '6qrtzfsh': {
      'es': '20/03/2022',
      'en': '20/03/2022',
    },
    'g3nye4l9': {
      'es': 'Campaña de marketing',
      'en': 'Marketing campaign',
    },
    'lqofwx7z': {
      'es': 'Cancelada',
      'en': 'Cancellations',
    },
    'tyu6dt9m': {
      'es': 'Camila mendez ',
      'en': 'Camila mendez ',
    },
    '6w3wlqyp': {
      'es': 'Acción - Stories ',
      'en': 'Acción - Stories ',
    },
    'z8nk82va': {
      'es': '20/03/2022',
      'en': '20/03/2022',
    },
    'u6pxceaw': {
      'es': 'Campaña de marketing',
      'en': 'Marketing campaign',
    },
    'emob7d79': {
      'es': 'Cancelada',
      'en': 'Cancellations',
    },
    'p3pf08an': {
      'es': 'SUSPENDER USUARIO',
      'en': 'SUSPEND USER',
    },
    '89oi8mul': {
      'es': 'Pagos comerciantes',
      'en': 'Merchant payments',
    },
    'q6fk9l9g': {
      'es': 'Resúmen de pagos y clases del usuario Julian Alonso.',
      'en': 'Summary of payments and classes of the user Julian Alonso.',
    },
    '7si4j0tb': {
      'es': 'Buscar...',
      'en': 'Search...',
    },
    'gs60kv4g': {
      'es': 'Resúmen',
      'en': 'Summary',
    },
    'faqb7t7t': {
      'es': 'Total del mes:',
      'en': 'Total for the month:',
    },
    'd72wxwa2': {
      'es': '\$ 7500',
      'en': '\$ 7500',
    },
    '72e0h9ko': {
      'es': 'Comentarios',
      'en': 'Comments',
    },
    'nwcczt56': {
      'es': 'Buscar...',
      'en': 'Search...',
    },
    'yf2tud1z': {
      'es': 'Sol Gomez',
      'en': 'Sol Gomez',
    },
    '1oivsvr6': {
      'es': 'Muy profesionales y muy ordenados con todos los pagos!',
      'en': 'Very professional and very organized with all payments!',
    },
    'lawt06vu': {
      'es': 'Sol Gomez',
      'en': 'Sol Gomez',
    },
    'wu9rw7dp': {
      'es': 'Muy profesionales y muy ordenados con todos los pagos!',
      'en': 'Very professional and very organized with all payments!',
    },
    'v9s3a2oy': {
      'es': 'Calendario',
      'en': 'Calendar',
    },
    'quqjdk6b': {
      'es': 'Buscar...',
      'en': 'Search...',
    },
    'we578k65': {
      'es': 'Nike',
      'en': 'Nike',
    },
    '7pc8y9ej': {
      'es': 'Campaña Welnness',
      'en': 'Welness Campaign',
    },
    'yfwzxgoo': {
      'es': '20/03/2022',
      'en': '20/03/2022',
    },
    'kya2eo8x': {
      'es': 'Nike',
      'en': 'Nike',
    },
    'wjlaxo2t': {
      'es': 'Campaña Welnness',
      'en': 'Welness Campaign',
    },
    'mqxbt30u': {
      'es': '20/03/2022',
      'en': '20/03/2022',
    },
    'gaii7q8k': {
      'es': 'Nike',
      'en': 'Nike',
    },
    'budmah79': {
      'es': 'Campaña Welnness',
      'en': '20/03/2022',
    },
    'hq8n8c0r': {
      'es': '20/03/2022',
      'en': '20/03/2022',
    },
    'h8wero5i': {
      'es': 'Estadísticas',
      'en': 'Statistics',
    },
    '540epbrx': {
      'es': 'OFERTAS ACEPTADAS',
      'en': 'OFFERS ACCEPTED',
    },
    's86m2d58': {
      'es': '100',
      'en': '100',
    },
    '3bk5v6np': {
      'es': 'en el último mes',
      'en': 'in last month',
    },
    'f1h2g814': {
      'es': ' INFLUENCERS  CON LOS QUE TRABAJO ',
      'en': 'INFLUENCERS I WORK WITH',
    },
    'co4oi7w9': {
      'es': '24',
      'en': '24',
    },
    'xkssxs2d': {
      'es': 'en el último mes',
      'en': 'in last month',
    },
    'k9hnxfx8': {
      'es': 'BAJAS DE INFLUENCERS',
      'en': 'INFLUENCER REMOVALS',
    },
    '18yx2xe6': {
      'es': '45',
      'en': '45',
    },
    'vvbawqqz': {
      'es': 'en el último mes',
      'en': 'in last month',
    },
    'vhy5u116': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // roles
  {
    'p8f2jd2y': {
      'es': 'Influencers',
      'en': 'Influencers',
    },
    'k27q6hdn': {
      'es': 'Comercios',
      'en': 'Trade',
    },
    'f4uppux9': {
      'es': 'Page Title',
      'en': 'Page Title',
    },
    '8z7td72o': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // listTest
  {
    '90drplcs': {
      'es': 'Añadir Miembros',
      'en': 'Add Members',
    },
    'kfwo5zor': {
      'es': 'Buscar Miembros...',
      'en': 'Search members...',
    },
    'vekqawcg': {
      'es': 'Miembros en Proyecto',
      'en': 'Members in Project',
    },
    'pq272lya': {
      'es': 'Nombre ',
      'en': 'UserName',
    },
    'm8ldtgz3': {
      'es': 'Eliminar',
      'en': 'Remove',
    },
    'm3rpgk3j': {
      'es': 'Nombre ',
      'en': 'UserName',
    },
    'qrpebqnx': {
      'es': 'Eliminar',
      'en': 'Remove',
    },
    '90mwn6bb': {
      'es': 'Nombre ',
      'en': 'UserName',
    },
    'uwbtjqfy': {
      'es': 'Eliminar',
      'en': 'Remove',
    },
    'sfnrzw5r': {
      'es': 'Añadir Miembro',
      'en': 'Add Members',
    },
    'qb7ni136': {
      'es': 'user@domainname.com',
      'en': 'user@domainname.com',
    },
    '157ooz6f': {
      'es': 'Ver',
      'en': 'View',
    },
    'yhuyi4mg': {
      'es': 'user@domainname.com',
      'en': 'user@domainname.com',
    },
    'kcd3m4ab': {
      'es': 'Ver',
      'en': 'View',
    },
    'ey1cs2ax': {
      'es': 'Nombre ',
      'en': 'Username',
    },
    'q734as8v': {
      'es': 'user@domainname.com',
      'en': 'user@domainname.com',
    },
    'sib8rxep': {
      'es': 'Ver',
      'en': 'View',
    },
    'ss5enjj6': {
      'es': 'Nombre ',
      'en': 'Username',
    },
    'z8e9s6zi': {
      'es': 'user@domainname.com',
      'en': 'user@domainname.com',
    },
    'ob7lla9h': {
      'es': 'Ver',
      'en': 'View',
    },
    '6avraojt': {
      'es': 'user@domainname.com',
      'en': 'user@domainname.com',
    },
    'su9kclt2': {
      'es': 'Ver',
      'en': 'View',
    },
    'tyx74o27': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I07ComercioInicioSecion
  {
    '8lo7fy5n': {
      'es': 'Iniciar Sesión',
      'en': 'Log in',
    },
    'vc9tr9fg': {
      'es': 'Email',
      'en': 'Email',
    },
    'u55zz8m5': {
      'es': 'Olvidé mi mail',
      'en': 'Forgot my email',
    },
    '4h43qkr9': {
      'es': 'Contraseña',
      'en': 'Password',
    },
    'kwp4rvqs': {
      'es': 'Olvide mi contraseña',
      'en': 'Forgot my Password',
    },
    'pgn6uyb3': {
      'es': 'Use las redes sociales para iniciar sesion',
      'en': 'Log in with social networks',
    },
    '17uj0f37': {
      'es': 'INICIAR SESION',
      'en': 'LOG IN',
    },
    'kgh52cdx': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I20MisOfertas
  {
    '6t0q0gpa': {
      'es': 'Mis Ofertas',
      'en': 'My Offer',
    },
    'kuclu8a1': {
      'es': 'Comida',
      'en': 'Food',
    },
    'izm0up3z': {
      'es': 'Fitness',
      'en': 'Fitness',
    },
    '2u1yxcw7': {
      'es': 'Inicio',
      'en': 'Home',
    },
  },
  // I33PerfilComercioYaNo
  {
    '4g5buj8z': {
      'es': 'Mi Perfil',
      'en': 'My Profile',
    },
    'ndprnc06': {
      'es': 'Editar Perfil',
      'en': 'Edit Profile',
    },
    'o2866ats': {
      'es': 'Editar perfil...',
      'en': 'Edit Profile...',
    },
    '121q8xnx': {
      'es': 'Mis Ofertas',
      'en': 'My Offer',
    },
    'b635vldp': {
      'es': 'Ver mis ofertas...',
      'en': 'View my Offer...',
    },
    'u86hxdbs': {
      'es': 'Crear Oferta',
      'en': 'Add Offer',
    },
    '1ik1ksk2': {
      'es': 'Crear nueva oferta...',
      'en': 'Add new offer...',
    },
    'qn1tmj2i': {
      'es': 'Soporte Técnico',
      'en': 'Technical support',
    },
    'eowc9w40': {
      'es': 'Responde tus preguntas...',
      'en': 'Answer your questions...',
    },
    'wmjc7879': {
      'es': 'Método de pago',
      'en': 'Payment method',
    },
    'w4yg7six': {
      'es': 'Mejor manera de recibir los....',
      'en': 'Best way to receive...',
    },
    'reveubl1': {
      'es': 'CERRAR SESIÓN',
      'en': 'LOG OUT',
    },
    '453he0en': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I34EditPerfilComercio
  {
    'yb03iz3t': {
      'es': 'Editar Cuenta',
      'en': 'Edit Profile',
    },
    'ysio7kmp': {
      'es': 'Información del Comercio',
      'en': 'Trade Information',
    },
    '5xid5grk': {
      'es': 'Claudia Fernandez',
      'en': 'Claudia Fernandez',
    },
    'gfcaxx1m': {
      'es': 'Claudia Fernandez',
      'en': 'Claudia Fernandez',
    },
    '8rhnmugg': {
      'es': '10/09/2023',
      'en': '10/09/2023',
    },
    'hs8wdzb8': {
      'es': '@Clau.fer',
      'en': '@Clau.fer',
    },
    'auugnz9r': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    'phuktkcu': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    '5ma0gm93': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    'bmrgi0sv': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    '7e2m6s87': {
      'es': 'Clu.fer@gmail.com',
      'en': 'Clu.fer@gmail.com',
    },
    'fwh8zwzp': {
      'es': 'Descripción',
      'en': 'Description',
    },
    'jxx9qrob': {
      'es': 'Descripción',
      'en': 'Description',
    },
    'yhyxmfsr': {
      'es': 'Ubicación',
      'en': 'Location',
    },
    'vqt22rk0': {
      'es': 'Ubicación',
      'en': '',
    },
    '6mdr7mix': {
      'es': 'Ciudad',
      'en': 'City',
    },
    '0e3mm4oi': {
      'es': 'Estado',
      'en': 'State',
    },
    'ydpjnde2': {
      'es': 'Pais',
      'en': 'Coutry',
    },
    'dqplgjy8': {
      'es': 'ZipCode',
      'en': 'ZipCode',
    },
    '0kv4tf2l': {
      'es': 'Dirección',
      'en': 'Address',
    },
    '65eam651': {
      'es': 'Actualizar Ubicación',
      'en': '',
    },
    'gerwxtz6': {
      'es': 'Ir a mí Ubicación',
      'en': 'Go to my Location',
    },
    '4mo0j0vq': {
      'es': 'GUARDAR',
      'en': 'SAVE',
    },
    'biatqkdn': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I20EstaNo
  {
    'j7x0vzau': {
      'es': 'Todas Ofertas',
      'en': 'All Offer',
    },
    '96jdz2la': {
      'es': 'Comida',
      'en': 'Food',
    },
    'lhvyie9k': {
      'es': 'Fitness',
      'en': 'Fitness',
    },
    'zni4ekuz': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I18MembresiasDetalles
  {
    '42lh6h87': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    'ajfcivu4': {
      'es': 'Membresías',
      'en': 'Memberships',
    },
    'dzot33je': {
      'es': ' / ',
      'en': '/',
    },
    '3uq5w06h': {
      'es': 'Mes',
      'en': 'Month',
    },
    '4hhx9ph4': {
      'es': 'ACEPTAR',
      'en': 'ACCEPT',
    },
    '8yzric5a': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // CrearNuevaOferta1
  {
    'tvq6sv8v': {
      'es': 'Nueva Oferta',
      'en': 'New Offer',
    },
    'h7ledhhf': {
      'es': 'Cantidad de influencer ',
      'en': 'Influencer quantity',
    },
    '8ptbc2ka': {
      'es': 'Ubicacion',
      'en': 'Location',
    },
    'kd6mfxkv': {
      'es': 'Fitness',
      'en': 'Fitness',
    },
    '0420w47y': {
      'es': 'Food',
      'en': 'Food',
    },
    'eponel5v': {
      'es': 'Selecciona Categoria...',
      'en': 'Select Category...',
    },
    'po3wil3o': {
      'es': 'Buscar por item...',
      'en': 'Search for an item...',
    },
    'vwebs8ww': {
      'es': 'Descripción del trabajo',
      'en': 'Work description',
    },
    'y7p4899b': {
      'es': 'Adjuntar Referencia',
      'en': 'Upload image',
    },
    'ui77hvq8': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    'wpkxmizd': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // InicioAPK
  {
    '5xkb5ooe': {
      'es': 'INFLUENCER',
      'en': 'INFLUENCER',
    },
    'zgyu0bel': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
    'yp4yxmom': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // Transicion
  {
    'm2nhwjig': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // RecoverPassword
  {
    'gmg58319': {
      'es': 'Recuperar Password',
      'en': 'Recover Password',
    },
    'xnp7v9gw': {
      'es':
          'Escriba su correo, luego presione en \"Enviar\". Revise su bandeja de cooreos y recibirá uno con las indicaciones para reestablecer su contraseña. Saludos, equipo ',
      'en':
          '\nWrite your email, then click on \"Send\". Check your email tray and you will receive one with instructions to reset your password. Regards, team',
    },
    'heu0hnlh': {
      'es': 'Lit',
      'en': 'Lit',
    },
    'o48usywy': {
      'es': 'Email...',
      'en': 'Email...',
    },
    'zafmoj85': {
      'es': 'Enviar',
      'en': 'Send',
    },
    'xh8iz839': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // EditarOferta
  {
    'aqzwjv0c': {
      'es': 'Nueva Oferta',
      'en': 'New Offer',
    },
    'rr6arlzf': {
      'es': 'Cantidad de influencer ',
      'en': 'Influencer quantity',
    },
    '6nyx95kg': {
      'es': 'Ubicacion',
      'en': 'Location',
    },
    '3ccfk1un': {
      'es': 'Fitness',
      'en': 'Fitness',
    },
    'qa0yqf11': {
      'es': 'Food',
      'en': 'Food',
    },
    'f2aewlhk': {
      'es': 'Selecciona Categoria...',
      'en': 'Select Category...',
    },
    'w093hn3i': {
      'es': 'Buscar por item...',
      'en': 'Search for an item...',
    },
    '9u6ug2ne': {
      'es': 'Descripción del trabajo',
      'en': 'Work description',
    },
    'imnh3i0r': {
      'es': 'Cargar imagen',
      'en': 'Upload image',
    },
    'kmupwgyl': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
    '1d573wmp': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // DetalleMiSolicitud
  {
    '5mgki1tk': {
      'es': '2km',
      'en': '2km',
    },
    'n3vmfyu5': {
      'es': 'Código - ',
      'en': 'Código - AD1234 ',
    },
    'kiytsx5f': {
      'es': 'Dejanos tu reseña en Google!\n',
      'en': 'Leave us your review on Google!',
    },
    '9kkr8f1d': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // IAtencionalclienteCopy
  {
    '5i0e6yh3': {
      'es': 'Atención al Cliente',
      'en': 'Atención al Cliente',
    },
    'dfn6fjz5': {
      'es':
          'Ey! ¿Cómo podemos ayudarte?\nSi estás teniendo problemas\ncon la app mandá:',
      'en':
          'Ey! ¿Cómo podemos ayudarte?\nSi estás teniendo problemas\ncon la app mandá:',
    },
    'spmc9qr8': {
      'es': '. ',
      'en': '. ',
    },
    'ajytzn25': {
      'es': '1. Tengo un problema\ncon la oferta.',
      'en': '1. Tengo un problema\ncon la oferta.',
    },
    'qhfyziez': {
      'es': '. ',
      'en': '. ',
    },
    '08lq11it': {
      'es': '2. Servicio Técnico.',
      'en': '1. Tengo un problema\ncon la oferta.',
    },
    'e6h11qhw': {
      'es': '',
      'en': 'Label here...',
    },
    'gwfz51hi': {
      'es': 'Escribir Aqui...',
      'en': '',
    },
    'clmv5l4l': {
      'es': 'Home',
      'en': 'Home',
    },
  },
  // I14MensajeClaveIncorrecta
  {
    'lziad38j': {
      'es': '¡Las contraseñas \nno coinciden!',
      'en': 'The passwords\ndo not match!',
    },
    'svbjmbyk': {
      'es': 'Verificá que ambas contraseñas \nsean iguales.',
      'en': 'Verify that both passwords\nbe equal.',
    },
    'tz7yefw3': {
      'es': 'REINTENTAR',
      'en': 'RETRY',
    },
  },
  // I13mensajeclavenueva
  {
    '0vu84ji7': {
      'es': 'Cambio realizado',
      'en': 'Change made',
    },
    'hanrxx9u': {
      'es': 'Tu contraseña ha sido modificada\ncorrectamente.',
      'en': 'Your password has been changed\ncorrectly.',
    },
    '4q39hyw8': {
      'es': 'COMENZAR',
      'en': 'START',
    },
  },
  // I209mensajedecodigoincorrecto
  {
    'clnqcn1z': {
      'es': 'Error',
      'en': 'Error',
    },
    'brggmxad': {
      'es': 'El código no coincide con el que te enviamos.',
      'en': 'The code does not match the one we sent you.',
    },
    'znp88ohz': {
      'es': 'REENVIAR CODIGO',
      'en': 'RESEND CODE',
    },
  },
  // I51Registroexitoso
  {
    'nvx3t073': {
      'es': 'Registro exitoso!',
      'en': 'Successful registration!',
    },
    '5mkon361': {
      'es': 'Estamos evaluando tu perfil. En breve nos pondremos en contacto.',
      'en': 'We are evaluating your profile. We will contact you shortly.',
    },
    's9ax2123': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
  },
  // I46Solicitudaceptada
  {
    'yruk0ura': {
      'es': 'Solicitud Aceptada',
      'en': 'Request accepted',
    },
    '2kikgmu8': {
      'es': 'Hola ',
      'en': 'Hello ',
    },
    '8025thut': {
      'es':
          ', tu solicitud a la oferta \nfue aceptada. \nSalí a divertirte y compartí tu experiencia.',
      'en':
          ', your request for the offer\nwas accepted.\nI went out to have fun and shared your experience.',
    },
    '324orrre': {
      'es': 'No te olvides de arrobar al comercio!',
      'en': 'Don\'t forget to throw in the trade!',
    },
    '8gmpd9uu': {
      'es': 'ACEPTAR',
      'en': 'ACCEPT',
    },
  },
  // I47sincronizarsolicitud
  {
    'aegqgmyu': {
      'es': 'Solicitud Aceptada',
      'en': 'Request accepted',
    },
    '7qz9wku9': {
      'es': 'Estimado ',
      'en': 'Dear',
    },
    'fzvknfim': {
      'es':
          ', su oferta ha sido aceptada. ¡Es hora de ponerse en marcha y hacer el trabajo!\n',
      'en':
          ', your offer has been accepted. It\'s time to get going and get the job done!',
    },
    'xg5x9p15': {
      'es': 'No te olvides de arrobar al comercio!',
      'en': 'Don\'t forget to throw in the trade!',
    },
    '228g93a7': {
      'es': 'Sincronizar calendario',
      'en': 'Sync calendar',
    },
    'occo1s20': {
      'es': 'Google Calendar',
      'en': 'Google Calendar',
    },
    'bs7l76qq': {
      'es': 'SINCRONIZAR',
      'en': 'SYNC',
    },
  },
  // I208ofertanodisponible
  {
    '2dpb7wea': {
      'es': 'Ups! La oferta de @Negroni\nya no esta disponible',
      'en': 'Ups! @Negroni\'s offer\nit\'s no longer available',
    },
    'nv9xpawy': {
      'es': 'Encontrá nuevas ofertas en el home.',
      'en': 'Find new offers in the home.',
    },
    '424qus6v': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
  },
  // I202masinformacionenviodemail
  {
    'ockgztpe': {
      'es': 'Vas a recibir un mail con\nmás informacion sobre la\noferta!',
      'en':
          'You will receive an email with\nmore information about the\noffer!',
    },
    '9vsxfddw': {
      'es': 'Aceptar',
      'en': 'Acept',
    },
  },
  // I197informaciondellugar
  {
    't05179yq': {
      'es': 'Negroni',
      'en': 'Negroni',
    },
    'ld42uh2m': {
      'es': 'Bar Premium',
      'en': 'Bar Premium',
    },
    'uwsdblpd': {
      'es':
          'Una propuesta diferente con \nespíritu Italo-Neoyorquino. \nSushibar, cocktails, cucina & beers. \nEstamos en Miami, Buenos Aires, \nPilar, Pinamar, Rosario, La Plata, \nCityBell, Montevideo y Asu. del\n Paraguay.',
      'en':
          'Una propuesta diferente con \nespíritu Italo-Neoyorquino. \nSushibar, cocktails, cucina & beers. \nEstamos en Miami, Buenos Aires, \nPilar, Pinamar, Rosario, La Plata, \nCityBell, Montevideo y Asu. del\n Paraguay.',
    },
  },
  // I196EliminarSolicitud
  {
    'fk75jzxh': {
      'es': '¿Estás seguro que\nquerés eliminar la oferta?',
      'en': 'Are you sure\nDo you want to remove the offer?',
    },
    '61guce9p': {
      'es':
          'Después de varias cancelaciones\nseguidas tu usuario será suspendido.',
      'en':
          'After several cancellations\nfollowed your user will be suspended.',
    },
    '7rgh8234': {
      'es': 'Cancelación ',
      'en': 'Cancellation',
    },
    'yrjpyrlk': {
      'es': '2',
      'en': '2',
    },
    'h3y7nrcj': {
      'es': '/3',
      'en': '/3',
    },
    'v3rkcx29': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    'db4h9gei': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I193VaciarChat
  {
    '5xgkzi4w': {
      'es': '¿Estás seguro que\nquerés eliminar la chat?',
      'en': 'Are you sure\nDo you want to delete the chat?',
    },
    '0ay6myii': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    'zrssrskn': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I45EliminarOferta
  {
    '3jl3llsa': {
      'es': '¿Seguro querés e\nliminar la oferta?',
      'en': 'Are you sure you want to\nremove the offer?',
    },
    'num6yn0e': {
      'es':
          'Después de varias cancelaciones\nseguidas tu usuario será suspendido.',
      'en':
          'After several cancellations\nfollowed your user will be suspended.',
    },
    '7zwujri6': {
      'es': 'Cancelación ',
      'en': '\nCancellation',
    },
    '1hpfus00': {
      'es': '2',
      'en': '2',
    },
    'ckft0yzg': {
      'es': '/3',
      'en': '/3',
    },
    'zzm45be8': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    'm8f1u4w4': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I192borrarnotificaciones
  {
    'ls66j3qh': {
      'es': '¿Estás seguro que\nquerés eliminar la historial?',
      'en': 'Are you sure\nDo you want to delete the history?',
    },
    'zusvz7rp': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    'fylwqmhv': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I36CerrarSesion
  {
    '834ecagq': {
      'es': 'Cerrar Sesión',
      'en': 'Sign off',
    },
    '16zosju0': {
      'es': 'Estás seguro de que querés\ncerrar sesión?',
      'en': 'Are you sure you want\nSign off?',
    },
    'o3mgnk1z': {
      'es': 'CERRAR SESIÓN',
      'en': 'LOG OUT',
    },
    'v97dlnl4': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I39sincronizandocuenta
  {
    '2mehm7ce': {
      'es': 'Se sincronizó tu cuenta!',
      'en': 'Your account has been synced!',
    },
    '6l3cpvg8': {
      'es': 'Redireccionando a Mercado Pago...',
      'en': 'Redirecting to Mercado Pago...',
    },
  },
  // I161Registroexitoso
  {
    'ubv3j92z': {
      'es': 'Registro exitoso!',
      'en': 'Successful registration!',
    },
    '0hklj0ar': {
      'es': 'Estamos evaluando tu perfil. En breve nos pondremos en contacto.',
      'en': 'We are evaluating your profile. We will contact you shortly.',
    },
    '7r1rcnze': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
  },
  // I34contrasenasnocoinciden
  {
    'jrf6j1wh': {
      'es': '¡Las contraseñas \nno coinciden!',
      'en': 'The passwords\ndo not match!',
    },
    '3k8po7m1': {
      'es': 'Verificá que ambas contraseñas \nsean iguales.',
      'en': 'Verify that both passwords\nbe equal.',
    },
    '3akgtxcf': {
      'es': 'REINTENTAR',
      'en': 'RETRY',
    },
  },
  // I33codigonococincide
  {
    'k7ib9jwk': {
      'es': 'Error',
      'en': 'Error',
    },
    's3r06pae': {
      'es': 'El código no coincide con el que te\nenviamos.',
      'en': 'The code does not match the one you\nwe send.',
    },
    '2spzkkus': {
      'es': 'REENVIAR CODIGO',
      'en': 'RESEND CODE',
    },
  },
  // I13cambiorealizado
  {
    'km7y70w1': {
      'es': 'Registro exitoso!',
      'en': 'Successful registration!',
    },
    'dfnwfbn0': {
      'es': 'Tu contraseña ha sido modificada \ncorrectamente.',
      'en': 'Your password has been changed\ncorrectly.',
    },
    'd0e644tq': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
  },
  // yasosparte
  {
    'ynyci84a': {
      'es': 'Ya sos parte de Lit!',
      'en': 'You are already part of Lit!',
    },
    'h8vdux2r': {
      'es': 'VINCULAR MIS PAGOS',
      'en': 'LINK MY PAYMENTS',
    },
  },
  // bienvenido
  {
    '3hcf6bx3': {
      'es': 'Bienvenido!',
      'en': 'Welcome!',
    },
  },
  // I174sincronizaciondecuenta
  {
    'oxjpskar': {
      'es': 'Se sincronizó tu cuenta!',
      'en': 'Your account has been synced!',
    },
    '0cobzc4z': {
      'es': 'Redireccionando a Mercado Pago...',
      'en': 'Redirecting to Mercado Pago...',
    },
  },
  // headercomercioruedita
  {
    'u1oifp41': {
      'es': 'COMERCIO',
      'en': 'TRADE',
    },
  },
  // I192ofertapublicada
  {
    'chwybojf': {
      'es': 'Oferta Publicada!',
      'en': 'Posted Offer!',
    },
    '5rgcto2w': {
      'es':
          'Preparate para recibir todo el talento de nuestra comunidad de influencers',
      'en':
          'Get ready to receive all the talent from our community of influencers',
    },
    'o9u1bx6k': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
  },
  // I212aceptaron
  {
    'cla5c7ud': {
      'es': 'Aceptaron tu oferta',
      'en': 'They accepted your offer',
    },
    'ni5obsf8': {
      'es': '@Influencer aceptó',
      'en': '@Influencer acept',
    },
    'jdr1reuz': {
      'es': 'VER OFERTA',
      'en': 'VIEW OFFER',
    },
  },
  // niveldeinfluencer
  {
    'x0h9ry68': {
      'es': 'Nano Influencer',
      'en': 'Nano Influencer',
    },
    'vctw9squ': {
      'es': 'Mega Influencer',
      'en': 'Mega Influencer',
    },
    'gvm2sdls': {
      'es': 'Micro Influencer',
      'en': 'Micro Influencer',
    },
    '5s1csx1j': {
      'es': 'Macro Influencer',
      'en': 'Macro Influencer',
    },
  },
  // categorias
  {
    'htbyhums': {
      'es': 'Comida',
      'en': 'Food',
    },
    'ika0uzs8': {
      'es': 'Fitness',
      'en': 'Fitness',
    },
    '20t1ktb6': {
      'es': 'Wellness',
      'en': 'Wellness',
    },
  },
  // Descripcionpropuesta
  {
    'zkoeiq3s': {
      'es': 'Drinks  + entradas',
      'en': 'Drinks + tickets',
    },
    'efrci1b8': {
      'es': 'Pizza party',
      'en': 'Pizza party',
    },
    'vjk047yk': {
      'es': 'Sushi + Aperol ',
      'en': 'Sushi + Aperol ',
    },
    'f0kizufo': {
      'es': 'Cafe + brunch',
      'en': 'Coffe + brunch',
    },
  },
  // horario
  {
    'ytl3lwv1': {
      'es': 'Cena',
      'en': 'Dinner',
    },
    'sw2jopah': {
      'es': 'Brunch',
      'en': 'Brunch',
    },
    'c97suuic': {
      'es': 'Almuerzo',
      'en': 'Lunch',
    },
    'ip6ik67k': {
      'es': 'Desayuno',
      'en': 'Breakfast',
    },
  },
  // campanaconinfluencer
  {
    '7zeoof31': {
      'es': 'Campaña de marketing',
      'en': 'Marketing campaign',
    },
    'p8d1y9ia': {
      'es': 'Campaña con influencer',
      'en': 'Influencer campaign',
    },
  },
  // plataforma
  {
    '8l6s7n70': {
      'es': 'Instagram',
      'en': 'Instagram',
    },
    '7xubv2l0': {
      'es': 'Tik Tok',
      'en': 'Tik Tok',
    },
    '27e0g0bw': {
      'es': 'Youtube',
      'en': 'Youtube',
    },
    '37alt9a4': {
      'es': 'Twitch',
      'en': 'Twitch',
    },
  },
  // formatopublicacion
  {
    'izv94xjv': {
      'es': 'Posteo',
      'en': 'Post',
    },
    'emlll8or': {
      'es': 'Stories',
      'en': 'Story',
    },
    'l14x48o8': {
      'es': 'Reels',
      'en': 'Reels',
    },
  },
  // cantidaddepublicaciones
  {
    '8bpexgij': {
      'es': '1',
      'en': '1',
    },
    'o8ss0zkn': {
      'es': '2',
      'en': '2',
    },
    'ir7b0kqu': {
      'es': '3',
      'en': '3',
    },
    '6h21c5ip': {
      'es': '4',
      'en': '4',
    },
  },
  // I205
  {
    'ypvxvf71': {
      'es': '¡Llegaste al máximo!',
      'en': 'You maxed out!',
    },
    't0ba9uvb': {
      'es':
          'Para seleccionar a este influencer tenés que hacer un upgrade en tu membresía.',
      'en': 'To select this influencer you have to upgrade your membership.',
    },
    'i6c4otfg': {
      'es': 'UPGRADE',
      'en': 'UPGRADE',
    },
    'eo5ji4gr': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I206
  {
    'y7s9a060': {
      'es': 'Ups!',
      'en': 'Ups!',
    },
    'bbo0bmqd': {
      'es':
          'Este influencer no está dentro tu membresía. Hacé el upgrade y disfrutá más beneficios.',
      'en':
          'This influencer is not in your membership. Upgrade and enjoy more benefits.',
    },
    'jq2bjglc': {
      'es': 'UPGRADE',
      'en': 'UPGRADE',
    },
    'zmp9z69q': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I208upgraderealizado
  {
    'l9tkos9q': {
      'es': 'Upgrade Realizado!',
      'en': 'Upgrade Done!',
    },
    '379d1n3q': {
      'es': 'Ya sos “Platinum”. Empezá a disfrutar más beneficios.',
      'en': 'You are already “Platinum”. Start enjoying more benefits.',
    },
    'bcaxbd16': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
  },
  // I210baja
  {
    'mcr0shm2': {
      'es': 'El influencer @pedroalonso se dio de baja ',
      'en': 'The influencer @pedroalonso unsubscribed',
    },
    '6dht0wt5': {
      'es': 'Podés elegir un nuevo influencer para tu oferta',
      'en': 'You can choose a new influencer for your offer',
    },
    'i6dklm07': {
      'es': 'BUSCAR NUEVO INFLUENCER',
      'en': 'SEARCH NEW INFLUENCER',
    },
  },
  // I209BAJA2
  {
    'hn1wymd1': {
      'es': 'El influencer @pedroalonso se dio de baja ',
      'en': 'The influencer @pedroalonso unsubscribed',
    },
    'et7vqywh': {
      'es': 'Se asignará un nuevo influencer para tu oferta',
      'en': 'A new influencer will be assigned for your offer',
    },
    'bwrkxygs': {
      'es': 'VER OFERTA',
      'en': 'VIEW OFFER',
    },
  },
  // I115eliminaroferta
  {
    'ku5et4az': {
      'es': '¿Seguro querés eliminar la oferta?',
      'en': 'Are you sure you want to\nremove the offer?',
    },
    '4gecc9is': {
      'es':
          'Después de varias cancelaciones\nseguidas tu usuario será suspendido.',
      'en':
          'After several cancellations\nfollowed your user will be suspended.',
    },
    '7r57pk74': {
      'es': 'Cancelación ',
      'en': 'Cancellation',
    },
    'xe3351en': {
      'es': '2',
      'en': '2',
    },
    'ajmuax66': {
      'es': '/3',
      'en': '/3',
    },
    'hkigd5fv': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    'sww4w11v': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I181califarinfluencer
  {
    'vbvg8e92': {
      'es': 'Califica al influencer',
      'en': 'rate the influencer',
    },
    'j5l5bmj6': {
      'es': 'Por favor calificá el trabajo del influencer.',
      'en': 'Please rate the influencer\'s work.',
    },
    '3v3jnd06': {
      'es': 'CALIFICAR',
      'en': 'QUALIFY',
    },
  },
  // I204eliminaroferta
  {
    'ymk7dosu': {
      'es': '¿Seguro querés e\nliminar la oferta?',
      'en': 'Are you sure you want to\nremove the offer?',
    },
    'e7hooa5x': {
      'es':
          'Después de varias cancelaciones\nseguidas tu usuario será suspendido.',
      'en':
          'After several cancellations\nfollowed your user will be suspended.',
    },
    'jglciu12': {
      'es': 'Cancelación ',
      'en': 'Cancellation',
    },
    '2rvnknhg': {
      'es': '2',
      'en': '2',
    },
    'pm7l2oyv': {
      'es': '/3',
      'en': '/3',
    },
    'emby6a41': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    '9947dz7r': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // Pago
  {
    '2zvmxtf6': {
      'es': 'Mensual',
      'en': 'Month',
    },
    '7u1a2yf6': {
      'es': '5% off',
      'en': '5% off',
    },
    '0i4tvc6m': {
      'es': 'Trimestral',
      'en': 'Quarterly',
    },
    '8pvuzglb': {
      'es': '20% off',
      'en': '20% off',
    },
    'cgjs9jbw': {
      'es': 'Anual',
      'en': 'Year',
    },
    'c9f3wd4b': {
      'es': '50% off',
      'en': '50% off',
    },
  },
  // upgraderealizado
  {
    'hreozumr': {
      'es': 'Upgrade realizado!',
      'en': 'Upgrade done!',
    },
  },
  // I200eliminarchat
  {
    'gijc6un5': {
      'es': '¿Estás seguro que\nquerés eliminar la chat?',
      'en': 'Are you sure\nDo you want to delete the chat?',
    },
    '6z71a6mu': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    'j03dkl3w': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I159eliminaroferta
  {
    '7yt4xw7g': {
      'es': '¿Seguro querés e\nliminar la oferta?',
      'en': 'Are you sure you want to\nremove the offer?',
    },
    'i9f8so7b': {
      'es':
          'Después de varias cancelaciones\nseguidas tu usuario será suspendido.',
      'en':
          'After several cancellations\nfollowed your user will be suspended.',
    },
    'medb0489': {
      'es': 'Cancelación ',
      'en': '\nCancellation',
    },
    'eicg4ckp': {
      'es': '2',
      'en': '2',
    },
    '29t0pnvg': {
      'es': '/3',
      'en': '/3',
    },
    '10qiu4ym': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    'merannbz': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I202Eliminarhistorial
  {
    '3iobi3zi': {
      'es': '¿Estás seguro que\nquerés eliminar la historial?',
      'en': 'Are you sure\nDo you want to delete the history?',
    },
    'yjsih7yv': {
      'es': 'ELIMINAR',
      'en': 'DELETE',
    },
    '4tdofou7': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // I39comercio
  {
    'fvixzend': {
      'es': 'Se sincronizó tu cuenta!',
      'en': 'Your account has been synced!',
    },
    '2hn3gckx': {
      'es': 'Redireccionando a Mercado Pago...',
      'en': 'Redirecting to Mercado Pago...',
    },
  },
  // I141cerrarsesion
  {
    'wlnan392': {
      'es': 'Cerrar Sesión',
      'en': 'Log Out',
    },
    '7gw9ucbc': {
      'es': '¿Seguro querés cerrar sesión?',
      'en': 'Are you sure you want to log out?',
    },
    '3ogzeklq': {
      'es': 'CERRAR SESIÓN',
      'en': 'LOG OUT',
    },
    'xddpnhlf': {
      'es': 'CANCELAR',
      'en': 'CANCEL',
    },
  },
  // SideBar
  {
    'j8b2ifvr': {
      'es': 'Comercios',
      'en': 'Trade',
    },
    'q4kbplx7': {
      'es': 'Notificaciones',
      'en': 'Notifications',
    },
    'mc8ktnre': {
      'es': 'Membresias',
      'en': 'Memberships',
    },
    '8sxcmq3a': {
      'es': 'Influencers',
      'en': 'Influencers',
    },
    'jsvkpokj': {
      'es': 'Ofertas',
      'en': 'Ofert',
    },
    'x2h7h7yt': {
      'es': 'Administración general',
      'en': 'General Administration',
    },
    'dwamur0q': {
      'es': 'Chat',
      'en': 'Chat',
    },
    'yltgerjb': {
      'es': 'Cerrar sesión',
      'en': 'Log Out',
    },
  },
  // navbar
  {
    'iqvlzp1p': {
      'es': 'Nombre admin',
      'en': 'Admin Name',
    },
    'v5svqrut': {
      'es': 'Buscar',
      'en': 'Search',
    },
  },
  // mostrarcomo
  {
    'p8ttsurc': {
      'es': 'Porcentaje',
      'en': 'Porcent',
    },
    '0ki5dss3': {
      'es': 'Número',
      'en': 'Number',
    },
  },
  // A4EditarComercio
  {
    'viw0nwty': {
      'es': 'Editar Comercio',
      'en': 'Edit Trade',
    },
    'g6zpmyj6': {
      'es': '46 Street',
      'en': '46 Street',
    },
    'u1uiscud': {
      'es': 'Moda',
      'en': 'Moda',
    },
    'h5bmxm7y': {
      'es': 'Buscar por item...',
      'en': 'Search for an item...',
    },
    'l1lgarlv': {
      'es': '46s@gmail.com',
      'en': '46s@gmail.com',
    },
    'cone7vrt': {
      'es': 'Juan Perez',
      'en': 'Juan Perez',
    },
    '7qrb0jn5': {
      'es': '************',
      'en': '************',
    },
    'gagy6omu': {
      'es': '+5491134567899',
      'en': '+5491134567899',
    },
    '4jg2tx7q': {
      'es': 'Juan Garlos Gruz 100',
      'en': 'Juan Garlos Gruz 100',
    },
    'clkrr7p8': {
      'es': 'Platinum',
      'en': 'Platinum',
    },
    'zxpsa8qh': {
      'es': 'Buscar por item...',
      'en': 'Search for an item...',
    },
    'r4vfvdsj': {
      'es': 'GUARDAR CAMBIO',
      'en': 'SAVE CHANGES',
    },
  },
  // A5Editarcomercio
  {
    'ph6je9j2': {
      'es': 'Se ha editado correctamente la inormación de @46Street',
      'en': 'Correctly edited @46Street info',
    },
    'do3r0uuf': {
      'es':
          ' Automáticamente se le enviará una notificación al comercio, \ninformándole los cambios realizados. ',
      'en':
          'A notification will automatically be sent to the merchant,\ninforming you of the changes made.',
    },
    'ug52mkbu': {
      'es': 'GUARDAR',
      'en': 'SAVE',
    },
  },
  // A6Comecrio
  {
    'j61fenaf': {
      'es': '4 usuarios alcanzaron el límite de cancelaciones!',
      'en': '4 users reached the cancellation limit!',
    },
    '5o7vzgc4': {
      'es': 'Puedes ir al perfil para suspender a dichos usuarios.',
      'en': 'You can go to the profile to suspend such users.',
    },
    'bebzq92h': {
      'es': 'CONTINUAR',
      'en': 'CONTINUE',
    },
  },
  // filter
  {
    'fq6b649z': {
      'es': 'Mejor a peor',
      'en': 'better to worse',
    },
    'ap6510n3': {
      'es': 'Mas recientes',
      'en': 'Most recent',
    },
  },
  // A8comercio
  {
    'bkjjcoqy': {
      'es': 'Se ha editado información del comercio',
      'en': 'Trade information has been edited',
    },
    'vak9sukr': {
      'es':
          'Automáticamente se le enviará una notificación al comercio, informándole los cambios realizados.',
      'en':
          'A notification will automatically be sent to the merchant, informing them of the changes made.',
    },
    'jpegg5iq': {
      'es': 'ACEPTAR',
      'en': 'ACCEPT',
    },
  },
  // I55Genero
  {
    '3pf4orfl': {
      'es': 'Femenino',
      'en': 'Female',
    },
    'kivib6uk': {
      'es': 'Masculino',
      'en': 'Male',
    },
  },
  // I207porcentaje
  {
    'i8nn89wn': {
      'es': '10%',
      'en': '10%',
    },
    'i4lfw7sy': {
      'es': '15%',
      'en': '15%',
    },
    '9lk5xjl5': {
      'es': '25%',
      'en': '25%',
    },
  },
  // I206representante
  {
    '12x8hfkh': {
      'es': 'Nombre del representante',
      'en': 'Name of the representative',
    },
    'ghqvofof': {
      'es': 'Porcentaje del representante',
      'en': 'Representative Percentage',
    },
  },
  // I207rol
  {
    '8twyovfb': {
      'es': 'Dueño',
      'en': 'Owner',
    },
    'umypgk02': {
      'es': 'Director X',
      'en': 'Director X',
    },
    'wvqle87r': {
      'es': 'Otro',
      'en': 'Other',
    },
  },
  // itemChat
  {
    'u5ofpspe': {
      'es': 'Hello World',
      'en': 'Hello World',
    },
    'rxttkskr': {
      'es': 'Hello World',
      'en': 'Hello World',
    },
    'edlbpi31': {
      'es': 'Hello World',
      'en': 'Hello World',
    },
    'oc1xb84a': {
      'es': 'Hello World',
      'en': 'Hello World',
    },
  },
  // Miscellaneous
  {
    '3tlk1ehv': {
      'es': '',
      'en': '',
    },
    'vprnh636': {
      'es': '',
      'en': '',
    },
    '1r0f2ezo': {
      'es': 'Lit solicita permiso para acceder a las notificaciones',
      'en': '',
    },
    '65uttrkp': {
      'es': '',
      'en': '',
    },
    'nt3re6xj': {
      'es': '',
      'en': '',
    },
    '5qao1r3i': {
      'es': '',
      'en': '',
    },
    'nj0jlnw2': {
      'es': '',
      'en': '',
    },
    'fjy5qxnr': {
      'es': '',
      'en': '',
    },
    'vuywi6qg': {
      'es': '',
      'en': '',
    },
    'm1oafmo5': {
      'es': '',
      'en': '',
    },
    'b2dsjrmf': {
      'es': '',
      'en': '',
    },
    '5lvvjef5': {
      'es': '',
      'en': '',
    },
    'u0278xj4': {
      'es': '',
      'en': '',
    },
    'rz82xe2a': {
      'es': '',
      'en': '',
    },
    '0emybgfo': {
      'es': '',
      'en': '',
    },
    'rcxz9996': {
      'es': '',
      'en': '',
    },
    'i8fkh9np': {
      'es': '',
      'en': '',
    },
    'xkpmeej0': {
      'es': '',
      'en': '',
    },
    'wo0q5dze': {
      'es': '',
      'en': '',
    },
    '0n40mttl': {
      'es': '',
      'en': '',
    },
    'v15xht7m': {
      'es': '',
      'en': '',
    },
    'x8wys0ju': {
      'es': '',
      'en': '',
    },
    'u09eudca': {
      'es': '',
      'en': '',
    },
    'yv06ugyv': {
      'es': '',
      'en': '',
    },
  },
].reduce((a, b) => a..addAll(b));
